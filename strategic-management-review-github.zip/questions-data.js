window.QUESTION_BANK = {
  "title": "Strategic Management Review",
  "chapters": [
    {
      "number": 1,
      "title": "Chapter 1 Strategic Management and Strategic Competitiveness",
      "questions": [
        {
          "id": "ch1-q41",
          "sourceNumber": 41,
          "type": "multiple-choice",
          "prompt": "A firm has achieved ______ when it successfully formulates and implements a value-creating strategy.",
          "options": {
            "A": "strategic competitiveness",
            "B": "a permanently sustainable competitive advantage",
            "C": "substantial returns",
            "D": "legal and ethical core values"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q42",
          "sourceNumber": 42,
          "type": "multiple-choice",
          "prompt": "A competitive advantage:",
          "options": {
            "A": "can be permanent if the firm has successfully implemented the strategic management process.",
            "B": "entails reducing investors' risk to near zero.",
            "C": "can be identified when competitors are unable to duplicate or find it too costly to try to imitate.",
            "D": "exists when competing firms are unable to find investors."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q43",
          "sourceNumber": 43,
          "type": "multiple-choice",
          "prompt": "Above-average returns are;",
          "options": {
            "A": "higher profits than the firm earned the previous year.",
            "B": "higher profits than the industry averaged over the last 10 years.",
            "C": "profits in excess of what an investor expects to earn from a historical pattern of performance of the firm.",
            "D": "returns in excess of what an investor expects to earn from other investments with a similar level of risk."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q44",
          "sourceNumber": 44,
          "type": "multiple-choice",
          "prompt": "The strategic management process is;",
          "options": {
            "A": "a set of activities that will assure a sustainable competitive advantage and above-average returns for the firm.",
            "B": "a decision-making activity concerned with a firm's internal resources, capabilities, and competencies, independent of the conditions in its external environment.",
            "C": "a process directed by top-management with input from other stakeholders that seeks to achieve above-average returns for investors through effective use of the organization's resources.",
            "D": "the formulation and implementation of a full set of commitments, decisions, and actions required for the firm to achieve above-average returns and strategic competitiveness."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q45",
          "sourceNumber": 45,
          "type": "multiple-choice",
          "prompt": "According to Hitt, the primary drivers of hypercompetition are:",
          "options": {
            "A": "rising global socio-economic instability and increased inflation.",
            "B": "the emergence of a global economy and rapid technological change.",
            "C": "increased global competition and decreased tariffs.",
            "D": "increased availability of capital and increased competition."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q46",
          "sourceNumber": 46,
          "type": "multiple-choice",
          "prompt": "All of the following are characteristics of the global economy EXCEPT:",
          "options": {
            "A": "the increasing importance of developing countries as sources of revenue growth.",
            "B": "the free movement of goods, services, people, skills, and ideas across geographic borders.",
            "C": "the increased use of tariffs to protect industries.",
            "D": "higher levels of opportunities and challenges in new geographic markets."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q47",
          "sourceNumber": 47,
          "type": "multiple-choice",
          "prompt": "Essentially, _______ has become one of the world's largest markets with 700 million potential consumers.",
          "options": {
            "A": "the European Union",
            "B": "the United States",
            "C": "China",
            "D": "Japan"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q48",
          "sourceNumber": 48,
          "type": "multiple-choice",
          "prompt": "______ has become the second-largest economy in the world.",
          "options": {
            "A": "The United States",
            "B": "The European Union",
            "C": "Japan",
            "D": "China"
          },
          "answer": "D"
        },
        {
          "id": "ch1-q49",
          "sourceNumber": 49,
          "type": "multiple-choice",
          "prompt": "The economic interdependence among countries which is reflected in the flow of goods, services, financial capital, and knowledge across country borders is defined as:",
          "options": {
            "A": "hypercompetition.",
            "B": "boundaryless retailing.",
            "C": "strategic intensity.",
            "D": "globalization."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q50",
          "sourceNumber": 50,
          "type": "multiple-choice",
          "prompt": "Globalization has led to:",
          "options": {
            "A": "lower operational efficiency as firms must transport raw materials and finished goods farther.",
            "B": "increasing loyalty of customers for products made domestically.",
            "C": "declining returns from investment in research and development.",
            "D": "higher performance standards including quality and cost."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q51",
          "sourceNumber": 51,
          "type": "multiple-choice",
          "prompt": "The \"liability of foreignness\" is the:",
          "options": {
            "A": "inability of most U.S. managers to truly comprehend foreign cultures.",
            "B": "political disadvantage that U.S. firms have when doing business abroad.",
            "C": "overall risk of participating outside a firm's domestic country when entering global competition.",
            "D": "preference for \"buying local,\" which always puts foreign firms at a disadvantage when competing in the U.S. market."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q52",
          "sourceNumber": 52,
          "type": "multiple-choice",
          "prompt": "Even for companies capable of succeeding in global markets, it is critical that they:",
          "options": {
            "A": "remain committed to and strategically competitive in their domestic market.",
            "B": "introduce many new products immediately after entering a new market.",
            "C": "acquire a local competitor in each significant foreign market.",
            "D": "develop good negotiating skills in order to take advantage of local suppliers in the international market."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q53",
          "sourceNumber": 53,
          "type": "multiple-choice",
          "prompt": "The rate of technological diffusion is increasing. Which of the following was fastest in penetrating 25 percent of homes in the U.S. market?",
          "options": {
            "A": "Mobile Phone",
            "B": "Television",
            "C": "Personal Computer",
            "D": "Internet"
          },
          "answer": "D"
        },
        {
          "id": "ch1-q54",
          "sourceNumber": 54,
          "type": "multiple-choice",
          "prompt": "New markets created by iPods, PDAs, and Wi-Fi are a result of:",
          "options": {
            "A": "disruptive technologies.",
            "B": "global competition.",
            "C": "knowledge intensity.",
            "D": "hypercompetition."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q55",
          "sourceNumber": 55,
          "type": "multiple-choice",
          "prompt": "Henry Ford once said, “If I had asked people what they wanted, they would have said faster horses.” The invention of the car is an early example of:",
          "options": {
            "A": "the march of globalization.",
            "B": "rapid technological diffusion.",
            "C": "disruptive technologies.",
            "D": "products that were not imitated by competitors."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q56",
          "sourceNumber": 56,
          "type": "multiple-choice",
          "prompt": "A company’s ability to acquire knowledge is:",
          "options": {
            "A": "less important in the 21st century than in previous periods of business history.",
            "B": "an important source of competitive advantage in virtually all industries.",
            "C": "not considered an asset or resource for businesses.",
            "D": "only important in high technology industries."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q57",
          "sourceNumber": 57,
          "type": "multiple-choice",
          "prompt": "The CEO of Ridgeway, Inc., realizes that the company's survival depends on developing and acquiring knowledge. Which of the following actions by the CEO would be most consistent with this need?",
          "options": {
            "A": "Ensuring that all current unique knowledge of the firm is protected by patents",
            "B": "Planning extensive employee training and hiring educated and experienced employees",
            "C": "Investing in sophisticated databases in relevant knowledge areas",
            "D": "Establishing a system of organizational intelligence gathering"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q58",
          "sourceNumber": 58,
          "type": "multiple-choice",
          "prompt": "Knowledge is composed of all the following EXCEPT:",
          "options": {
            "A": "insight.",
            "B": "expertise.",
            "C": "information.",
            "D": "intelligence."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q59",
          "sourceNumber": 59,
          "type": "multiple-choice",
          "prompt": "Which of the following statements about organizational knowledge is correct?",
          "options": {
            "A": "Knowledge is an intangible resource.",
            "B": "The importance of knowledge is increasing.",
            "C": "The value of knowledge as a proportion of shareholder value is increasing.",
            "D": "All of these options are correct."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q60",
          "sourceNumber": 60,
          "type": "multiple-choice",
          "prompt": "In order to cope with hypercompetition, firms need to develop ______ through continuous learning.",
          "options": {
            "A": "competitive resilience",
            "B": "strategic flexibility",
            "C": "strategic power",
            "D": "competitive dominance"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q61",
          "sourceNumber": 61,
          "type": "multiple-choice",
          "prompt": "All of the following are assumptions of the industrial organization (I/O) model EXCEPT:",
          "options": {
            "A": "organizational decision makers are rational and committed to acting in the firm's best interests.",
            "B": "resources to implement strategies are firm-specific and attached to firms over the long-term.",
            "C": "the external environment is assumed to impose pressures and constraints that determine the strategies that result in above-average returns.",
            "D": "every firm in an industry controls similar strategically relevant resources."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q62",
          "sourceNumber": 62,
          "type": "multiple-choice",
          "prompt": "The industrial organization (I/O) model argues that:",
          "options": {
            "A": "the key factor in success is choosing the correct industry in which to compete.",
            "B": "the firm's internal resources and capabilities represent the foundation for development of a value-creating strategy.",
            "C": "the key to earning above-average returns is strategic flexibility.",
            "D": "the internal structure of the organization must match the industry in which it competes for it to earn above- average returns on investment."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q63",
          "sourceNumber": 63,
          "type": "multiple-choice",
          "prompt": "Which of the following statements is most consistent with the I/O view? Performance of a firm is most directly attributable to:",
          "options": {
            "A": "the power of the financial market stakeholders.",
            "B": "the resources the firm possesses.",
            "C": "the profitability of the industry in which the firm competes.",
            "D": "hypercompetition within the industry."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q64",
          "sourceNumber": 64,
          "type": "multiple-choice",
          "prompt": "Firms use the five forces model of competition to identify the ______ of the industry. It is measured by its _______.",
          "options": {
            "A": "size; number of competitors.",
            "B": "globalization; export percentages.",
            "C": "hypercompetition; technology diffusion.",
            "D": "attractiveness; profitability."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q65",
          "sourceNumber": 65,
          "type": "multiple-choice",
          "prompt": "Although Alibaba is competing in the internet services industry, it has improved its performance by focusing on innovation and service diversification. This improved performance is best explained by:",
          "options": {
            "A": "globalization.",
            "B": "the resource-based model.",
            "C": "the I/O model.",
            "D": "hypercompetition."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q66",
          "sourceNumber": 66,
          "type": "multiple-choice",
          "prompt": "An investor is considering in which of two start-up companies to invest. The investor has faith in the industrial organization model of above-average returns and is using that as a guideline to make a decision. Both start-up companies propose to manufacture health-focused foods with low salt, low sugar, high fiber, and no artificial additives. RexRich Foods has a business strategy of producing a differentiated product for which consumers will pay more. Green Pastures Foods is in the health-foods industry because of its internal culture and commitment to healthy lifestyles, but it does not have any executives with experience in food production. Which firm will the investor feel is most consistent with the model of industrial organization?",
          "options": {
            "A": "Green Pastures Foods",
            "B": "RexRich Foods",
            "C": "Both firms are consistent with the I/O approach.",
            "D": "At the entrepreneurial stage, the model that companies follow is not important."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q67",
          "sourceNumber": 67,
          "type": "multiple-choice",
          "prompt": "Research shows that approximately ______ percent of a firm's profitability is explained by the industry in which it competes, whereas ______ percent is explained by the firm's characteristics and actions.",
          "options": {
            "A": "90; 10",
            "B": "60; 40",
            "C": "36; 20",
            "D": "20; 36"
          },
          "answer": "D"
        },
        {
          "id": "ch1-q68",
          "sourceNumber": 68,
          "type": "multiple-choice",
          "prompt": "All of the following are resources of an organization EXCEPT:",
          "options": {
            "A": "an hourly production employee's ability to catch subtle quality defects in products.",
            "B": "oil drilling rights in a promising region.",
            "C": "weak competitors in the industry.",
            "D": "a charity's board of directors of experienced executives."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q69",
          "sourceNumber": 69,
          "type": "multiple-choice",
          "prompt": "All of the following are assumptions of the resource-based model EXCEPT:",
          "options": {
            "A": "each firm is a unique collection of resources and capabilities.",
            "B": "the industry's structural characteristics have little impact on a firm's performance over time.",
            "C": "capabilities are highly mobile across firms.",
            "D": "differences in resources and capabilities are the basis of competitive advantage."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q70",
          "sourceNumber": 70,
          "type": "multiple-choice",
          "prompt": "______ is a capacity for a set of resources to perform a task or an activity in an integrative manner.",
          "options": {
            "A": "A capability",
            "B": "A core competence",
            "C": "Sustainable competitive advantage",
            "D": "Organizational intelligence"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q71",
          "sourceNumber": 71,
          "type": "multiple-choice",
          "prompt": "When resources and capabilities serve as a source of competitive advantage for a firm, the firm has created a(n):",
          "options": {
            "A": "strategic mission.",
            "B": "inspiring vision.",
            "C": "core competence.",
            "D": "sustainable market niche."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q72",
          "sourceNumber": 72,
          "type": "multiple-choice",
          "prompt": "In the resource-based model, which of the following factors would be considered a key to organizational success?",
          "options": {
            "A": "Unique market niche",
            "B": "Weak competition",
            "C": "Economies of scale",
            "D": "Skilled employees"
          },
          "answer": "D"
        },
        {
          "id": "ch1-q73",
          "sourceNumber": 73,
          "type": "multiple-choice",
          "prompt": "To have the potential to become sources of competitive advantage, resources and capabilities must be non- substitutable, valuable, ______, and ______.",
          "options": {
            "A": "unique; easy to imitate.",
            "B": "easy to imitate; difficult to implement.",
            "C": "rare; costly to imitate.",
            "D": "easy to implement; unique."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q74",
          "sourceNumber": 74,
          "type": "multiple-choice",
          "prompt": "The resource-based model argues that:",
          "options": {
            "A": "all resources have the potential to be the basis of sustainable competitive advantage.",
            "B": "resources alone can be a source of sustainable competitive advantage.",
            "C": "the key to competitive success is the structure of the industry in which the firm competes.",
            "D": "resources that are valuable, rare, costly to imitate, and non-substitutable form the basis of a firm's core competencies."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q75",
          "sourceNumber": 75,
          "type": "multiple-choice",
          "prompt": "The resource-based view of the firm:",
          "options": {
            "A": "emphasizes that it is difficult to develop and sustain a competitive advantage based on resources alone.",
            "B": "argues that the industry environment has a stronger influence on firms' ability to implement strategies successfully than does the competitive environment.",
            "C": "calls for firms to focus on their homogeneous capabilities to compete against their rivals.",
            "D": "suggests that vision and mission are marketing messages not tied to strategic plans."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q76",
          "sourceNumber": 76,
          "type": "multiple-choice",
          "prompt": "The goal of the organization's ______ is to point the firm in the direction of where it would like to be in the years to come.",
          "options": {
            "A": "vision",
            "B": "mission",
            "C": "culture",
            "D": "strategy"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q77",
          "sourceNumber": 77,
          "type": "multiple-choice",
          "prompt": "The Princeton Alliance Church states in its website that \"PAC exists to help you live life to the fullest by knowing God, developing community and bringing hope.\" This pronouncement is most precisely a statement of organizational:",
          "options": {
            "A": "values.",
            "B": "structure.",
            "C": "vision.",
            "D": "culture."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q78",
          "sourceNumber": 78,
          "type": "multiple-choice",
          "prompt": "A firm's mission:",
          "options": {
            "A": "is a statement of a firm's business in which it intends to compete and the customers it intends to serve.",
            "B": "is an internally focused affirmation of the organization's financial, social, and ethical goals.",
            "C": "is mainly intended to emotionally inspire employees and other stakeholders.",
            "D": "is developed by a firm before the firm develops its vision."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q79",
          "sourceNumber": 79,
          "type": "multiple-choice",
          "prompt": "According to Hitt, the final responsibility for forming the organization's mission lies with the:",
          "options": {
            "A": "CEO.",
            "B": "top-management team.",
            "C": "employees.",
            "D": "organization's stakeholders."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q80",
          "sourceNumber": 80,
          "type": "multiple-choice",
          "prompt": "A key purpose of a mission statement is to inform _________what a firm is, what it seeks to accomplish and who it seeks to serve.",
          "options": {
            "A": "CEOs",
            "B": "stakeholders",
            "C": "regulators",
            "D": "former employees"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q81",
          "sourceNumber": 81,
          "type": "multiple-choice",
          "prompt": "Organizational stakeholders include:",
          "options": {
            "A": "unions.",
            "B": "host communities.",
            "C": "employees.",
            "D": "suppliers of capital."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q82",
          "sourceNumber": 82,
          "type": "multiple-choice",
          "prompt": "The interests of an organization's stakeholders often conflict, and the organization must prioritize its stakeholders if it cannot satisfy them all. The ______ is the most critical criterion in prioritizing stakeholders.",
          "options": {
            "A": "power of each stakeholder",
            "B": "urgency of satisfying each stakeholder",
            "C": "vulnerability of organizational stakeholders",
            "D": "social value of each stakeholder"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q83",
          "sourceNumber": 83,
          "type": "multiple-choice",
          "prompt": "Capital market stakeholders include:",
          "options": {
            "A": "industry competitors.",
            "B": "shareholders.",
            "C": "employees.",
            "D": "government regulators."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q84",
          "sourceNumber": 84,
          "type": "multiple-choice",
          "prompt": "Dissatisfied capital market stakeholders may:",
          "options": {
            "A": "sell their stock.",
            "B": "tighten loan covenants.",
            "C": "seek to increase their power.",
            "D": "All of these options are correct."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q85",
          "sourceNumber": 85,
          "type": "multiple-choice",
          "prompt": "Greenleaf Property Management has been earning below-average returns for the last three years. Which one of the following statements is true?",
          "options": {
            "A": "Greenleaf will be able to satisfy its multiple stakeholders easily as long as the stakeholders are committed to the strategic mission of the firm.",
            "B": "Greenleaf will be able to minimally satisfy the demands of each stakeholder.",
            "C": "Greenleaf will need to prioritize the demands of its stakeholders based on the political influence each wields.",
            "D": "Greenleaf will not be able to minimally satisfy all stakeholders."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q86",
          "sourceNumber": 86,
          "type": "multiple-choice",
          "prompt": "Product market stakeholders include the firm's customers, and the principal concern of this stakeholder group is:",
          "options": {
            "A": "maximizing the firm's return on investment.",
            "B": "receiving the highest-quality services in the industry at any price.",
            "C": "obtaining reliable products at the lowest possible price.",
            "D": "increasing the profitability of the firm."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q87",
          "sourceNumber": 87,
          "type": "multiple-choice",
          "prompt": "Generally speaking, product market stakeholders are satisfied when:",
          "options": {
            "A": "a firm achieves a balance between profit margins, costs paid to suppliers and prices set for customers.",
            "B": "a firm's profit margin yields an above-average return to its capital market stakeholders.",
            "C": "the interests of the firm's organizational stakeholders have been maximized.",
            "D": "the interests of all stakeholders have been at least minimally satisfied."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q88",
          "sourceNumber": 88,
          "type": "multiple-choice",
          "prompt": "Before liquidating during a bankruptcy, a company will take several actions to try to satisfy its ______ stakeholders.",
          "options": {
            "A": "capital market",
            "B": "product market",
            "C": "organizational",
            "D": "governmental"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q89",
          "sourceNumber": 89,
          "type": "multiple-choice",
          "prompt": "The Chambers of Commerce of cities and towns often implore citizens to buy from local businesses. This is because the organization's role as a taxpayer is most important to ______ as stakeholders.",
          "options": {
            "A": "major suppliers of capital",
            "B": "shareholders",
            "C": "host communities",
            "D": "unions"
          },
          "answer": "C"
        },
        {
          "id": "ch1-q90",
          "sourceNumber": 90,
          "type": "multiple-choice",
          "prompt": "A retail outlet can attempt several remedies to improve profitability to meet the expectations of its _______ stakeholders, including closing stores, changing the top management team, and seeking potential buyers.",
          "options": {
            "A": "product market",
            "B": "capital market",
            "C": "organizational",
            "D": "governmental"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q91",
          "sourceNumber": 91,
          "type": "multiple-choice",
          "prompt": "Organizational stakeholders are usually satisfied when",
          "options": {
            "A": "their return on investment has been maximized.",
            "B": "customers pay the highest sustainable price for the goods and services they receive.",
            "C": "companies provide a dynamic, stimulating, and rewarding work environment.",
            "D": "companies are paying the highest prices to suppliers."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q92",
          "sourceNumber": 92,
          "type": "multiple-choice",
          "prompt": "Product market stakeholders include",
          "options": {
            "A": "suppliers.",
            "B": "shareholders.",
            "C": "employees.",
            "D": "the firm's chief executive officer."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q93",
          "sourceNumber": 93,
          "type": "multiple-choice",
          "prompt": "Refuge Nursing Homes, Inc., (RNH) has been highly profitable in the past 10 years, providing its investors higher returns than those earned by its direct competitors' investors. RNH has a reputation for providing high-paying managerial and hourly-employee jobs. However, recent investigations have revealed that the nursing home residents have been provided substandard care, including non-nutritious and unappetizing meals, non-functional medical equipment, and inadequate patient-care staffing. Which statement best describes the situation?",
          "options": {
            "A": "RNH has been earning below-average returns, so it has had to prioritize the demands of its various stakeholders.",
            "B": "RNH has prioritized the demands of capital market stakeholders and organizational stakeholders, over the demands of product market stakeholders.",
            "C": "RNH has earned above-average returns and so has satisfied the needs of all relevant stakeholders.",
            "D": "RNH has been attempting to minimally satisfy the demands of all of its stakeholders."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q94",
          "sourceNumber": 94,
          "type": "multiple-choice",
          "prompt": "A prominent national website services company runs Super Bowl advertisements showing a small business owner working alone in the office on a project, during the big game. The message of the ad is that the company understands the sacrifices of its customers. This ad seeks to convey a sense of the organization's ____ to the product market stakeholders.",
          "options": {
            "A": "culture of recognition and reward",
            "B": "mission to radically shift the global economy toward small businesses",
            "C": "leadership as a technology company",
            "D": "personality as sports lovers"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q95",
          "sourceNumber": 95,
          "type": "multiple-choice",
          "prompt": "The global economy, globalization, rapid technological change, and the increasing importance of knowledge are creating the need to:",
          "options": {
            "A": "delegate strategic responsibilities to employees \"closer to the action.\"",
            "B": "split responsibilities between the CEO and the board of directors to minimize the possibility of corporate scandals triggered by unethical CEOs.",
            "C": "re-centralize the responsibility for strategy to the CEO.",
            "D": "expand the strategic responsibilities to all organizational stakeholders."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q96",
          "sourceNumber": 96,
          "type": "multiple-choice",
          "prompt": "The strategic leader's work is characterized by:",
          "options": {
            "A": "ambiguous decision situations where the best course of action is not always easy to identify.",
            "B": "a willingness to unify stakeholders through skillful manipulation.",
            "C": "an ability to identify solutions to long-range problems.",
            "D": "concentration on the practical day-to-day aspects of the organization's operations."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q97",
          "sourceNumber": 97,
          "type": "multiple-choice",
          "prompt": "A major assumption about the strategic management process is that it is:",
          "options": {
            "A": "inspired.",
            "B": "team-based.",
            "C": "rational.",
            "D": "inclusive."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q98",
          "sourceNumber": 98,
          "type": "multiple-choice",
          "prompt": ":A business-level strategy describes",
          "options": {
            "A": "the businesses in which the company intends to compete.",
            "B": "all policies and procedures used in functional departments.",
            "C": "the business unit's actions to exploit its competitive advantage over rivals.",
            "D": "a firm's resources, intent, and mission."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q99",
          "sourceNumber": 99,
          "type": "multiple-choice",
          "prompt": "In a diversified firm, corporate-level strategy is concerned with:",
          "options": {
            "A": "operating each individual business under the corporate umbrella.",
            "B": "determining how each functional department of the firm will operate.",
            "C": "determining in which businesses to compete and how resources will be allocated between businesses.",
            "D": "coordinating the vision and mission of each subsidiary firm."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q100",
          "sourceNumber": 100,
          "type": "multiple-choice",
          "prompt": "PGG Mining is making a strategic decision whether to shut down a coal mine in Pennsylvania. It is important to consider that the decision:",
          "options": {
            "A": "should be based solely on the results of the CEO’s approval of the mine’s general manager.",
            "B": "has ethical implications for organizational stakeholders.",
            "C": "need not be socially responsible if the firm is making below-average returns from the mine.",
            "D": "All of these choices are important to consider."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q101",
          "sourceNumber": 101,
          "type": "multiple-choice",
          "prompt": "A large corporation has earned a reputation for being a challenging work environment for employees, placing demands on employees’ time and pushing them to accomplish tasks, sometimes with little recognition. A recent audit found that the company was denying employees overtime pay despite the extra work. This is a reflection of the company’s:",
          "options": {
            "A": "core values of hard work to gain advancement.",
            "B": "unethical corporate culture.",
            "C": "lack of an organizational mission.",
            "D": "search for its core competencies."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q102",
          "sourceNumber": 102,
          "type": "multiple-choice",
          "prompt": "In smaller, new venture firms, returns are sometimes measured in terms of:",
          "options": {
            "A": "return on assets.",
            "B": "return on equity.",
            "C": "return on sales.",
            "D": "the amount and speed of growth."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q103",
          "sourceNumber": 103,
          "type": "multiple-choice",
          "prompt": "A ______ is an integrated and coordinated set of commitments and actions designed to exploit core competencies and gain a competitive advantage.",
          "options": {
            "A": "goal",
            "B": "strategy",
            "C": "tactic",
            "D": "mission"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q104",
          "sourceNumber": 104,
          "type": "multiple-choice",
          "prompt": "______ is an investor's uncertainty about the economic gains or losses that will result from a particular investment.",
          "options": {
            "A": "Return",
            "B": "Reward",
            "C": "Risk",
            "D": "Revenue"
          },
          "answer": "C"
        },
        {
          "id": "ch1-q105",
          "sourceNumber": 105,
          "type": "multiple-choice",
          "prompt": "The culmination of the strategic management process is:",
          "options": {
            "A": "performance.",
            "B": "strategy implementation.",
            "C": "strategy formulation.",
            "D": "analysis."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q106",
          "sourceNumber": 106,
          "type": "multiple-choice",
          "prompt": "Managers must adopt a new mind-set that values ______ and the challenges that evolve from constantly changing conditions.",
          "options": {
            "A": "flexibility",
            "B": "innovation",
            "C": "speed",
            "D": "All of these options are correct."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q107",
          "sourceNumber": 107,
          "type": "multiple-choice",
          "prompt": "______ innovation is a term used to describe how rapidly and consistently new, information-intensive technologies replace older ones.",
          "options": {
            "A": "Perpetual",
            "B": "Disruptive",
            "C": "Global",
            "D": "Diffusion"
          },
          "answer": "A"
        },
        {
          "id": "ch1-q108",
          "sourceNumber": 108,
          "type": "multiple-choice",
          "prompt": "______ provides the firm with new and up-to-date skill sets, which allow it to adapt to its environment as it encounters changes.",
          "options": {
            "A": "Strategic flexibility",
            "B": "Continuous learning",
            "C": "Knowledge",
            "D": "The Internet"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q109",
          "sourceNumber": 109,
          "type": "multiple-choice",
          "prompt": "The I/O model is grounded in:",
          "options": {
            "A": "anthropology.",
            "B": "psychology.",
            "C": "economics.",
            "D": "accounting."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q110",
          "sourceNumber": 110,
          "type": "multiple-choice",
          "prompt": "Firms use both the ______ and ______ models. In fact, these models complement each other in that one focuses outside the firm while the other focuses inside the firm.",
          "options": {
            "A": "industry; capability",
            "B": "I/O; resource-based",
            "C": "competition; competency",
            "D": "industry; competency"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q111",
          "sourceNumber": 111,
          "type": "multiple-choice",
          "prompt": "______ should establish a firm's individuality and should be inspiring and relevant to all stakeholders.",
          "options": {
            "A": "A strategy",
            "B": "A vision",
            "C": "A mission",
            "D": "A goal"
          },
          "answer": "C"
        },
        {
          "id": "ch1-q112",
          "sourceNumber": 112,
          "type": "multiple-choice",
          "prompt": "William Ackman is a hedge fund manager who owned a large share of J.C. Penney stock. He was also a member of the J.C. Penney board. He tried to get the CEO fired, but the board and top management said he breached his boardroom duties when he publicly disclosed information about the CEO search and financial condition of the company. He resigned from the board of directors. This is an example of a contentious relationship between:",
          "options": {
            "A": "the capital market stakeholders and the organizational stakeholders.",
            "B": "the organizational stakeholders and the product market stakeholders.",
            "C": "the capital market stakeholders and the product market stakeholders.",
            "D": "all the stakeholders."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q113",
          "sourceNumber": 113,
          "type": "multiple-choice",
          "prompt": "Strategic leaders are:",
          "options": {
            "A": "located only at the executive level.",
            "B": "located in different areas and levels.",
            "C": "the CEO, COO, and CFO only.",
            "D": "located at different levels, but only in the operating area of the organization."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q114",
          "sourceNumber": 114,
          "type": "multiple-choice",
          "prompt": "Successful strategic leaders are:",
          "options": {
            "A": "committed to helping the firm to create value for all stakeholder groups.",
            "B": "committed to nurturing those around them.",
            "C": "decisive.",
            "D": "All of these options are correct."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q115",
          "sourceNumber": 115,
          "type": "multiple-choice",
          "prompt": "Strategic delegation helps:",
          "options": {
            "A": "overload middle managers.",
            "B": "executives control strategy implementation.",
            "C": "avoid too much managerial hubris.",
            "D": "emphasize profit maximization."
          },
          "answer": "C"
        },
        {
          "id": "ch1-q116",
          "sourceNumber": 116,
          "type": "multiple-choice",
          "prompt": "Organizational culture refers to:",
          "options": {
            "A": "the social energy that drives, or fails to drive, the organization.",
            "B": "the complex set of ideologies, symbols, and core values that are shared throughout the firm.",
            "C": "what people do when no one else is looking.",
            "D": "All of these options are correct."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q117",
          "sourceNumber": 117,
          "type": "multiple-choice",
          "prompt": "Effective strategic leaders are chosen based on:",
          "options": {
            "A": "their capabilities and accumulation of human capital over time.",
            "B": "their single-minded focus on strategy formation.",
            "C": "their aptitude for strategy implementation.",
            "D": "their focus on innovation."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q118",
          "sourceNumber": 118,
          "type": "multiple-choice",
          "prompt": "Strategic leaders, ______, often work long hours, and their work is filled with ambiguous decision situations.",
          "options": {
            "A": "at the top of the organization",
            "B": "regardless of their location in the organization",
            "C": "in the finance area",
            "D": "in the operations area"
          },
          "answer": "B"
        },
        {
          "id": "ch1-q119",
          "sourceNumber": 119,
          "type": "multiple-choice",
          "prompt": "SWOT stands for",
          "options": {
            "A": "strategy, wealth, organization, and threats.",
            "B": "success, weakness, opportunities, and taxes.",
            "C": "strength, wealth, organization, and taxes.",
            "D": "strengths, weaknesses, opportunities, and threats."
          },
          "answer": "D"
        },
        {
          "id": "ch1-q120",
          "sourceNumber": 120,
          "type": "multiple-choice",
          "prompt": "In the strategic management process ASP stands for",
          "options": {
            "A": "analyses, successes, and purposes.",
            "B": "analyses, strategies, and performance.",
            "C": "ability, strategies, and purposes.",
            "D": "ability, successes, and performance."
          },
          "answer": "B"
        },
        {
          "id": "ch1-q121",
          "sourceNumber": 121,
          "type": "multiple-choice",
          "prompt": "The firm's ______ provide the foundation for choosing one or more ______ and deciding how to implement them.",
          "options": {
            "A": "analyses; strengths",
            "B": "abilities; strengths",
            "C": "analyses; strategies",
            "D": "abilities; strategies"
          },
          "answer": "C"
        },
        {
          "id": "ch1-q122",
          "sourceNumber": 122,
          "type": "multiple-choice",
          "prompt": "It is important to emphasize that almost all strategic management process decisions have ______ because they are related to how a firm interacts with its stakeholders.",
          "options": {
            "A": "ethical dimensions.",
            "B": "local dimensions.",
            "C": "political dimensions.",
            "D": "global dimensions."
          },
          "answer": "A"
        },
        {
          "id": "ch1-q123",
          "sourceNumber": 123,
          "type": "multiple-choice",
          "prompt": "A company competing in a single product market has",
          "options": {
            "A": "one corporate-level strategy.",
            "B": "one business-level strategy.",
            "C": "one business-level strategy for failure. It should seek to diversify.",
            "D": "one business-level strategy and one corporate-level strategy."
          },
          "answer": "D"
        }
      ]
    },
    {
      "number": 2,
      "title": "Chapter 2 The External Environment: Opportunities, Threats, Industry Competition, and Competitor Analysis",
      "questions": [
        {
          "id": "ch2-q39",
          "sourceNumber": 39,
          "type": "multiple-choice",
          "prompt": "BP, in response to the Deepwater Horizon oil spill, expected increased scrutiny from which of the following segments of the general environment?",
          "options": {
            "A": "political/legal",
            "B": "global",
            "C": "technological",
            "D": "sociocultural"
          },
          "answer": "A"
        },
        {
          "id": "ch2-q40",
          "sourceNumber": 40,
          "type": "multiple-choice",
          "prompt": "Coca-Cola and PepsiCo have been accused of contributing to the obesity problem in the United States. This accusation comes from the ______segment of the general environment.",
          "options": {
            "A": "economic",
            "B": "political/legal",
            "C": "technological",
            "D": "sociocultural"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q41",
          "sourceNumber": 41,
          "type": "multiple-choice",
          "prompt": "The recent joint ventures formed by BP with Russian and Indian partners show the importance of the ______ segment of the general environment in those countries that BP and other oil firms have to manage when contending with scarce resources.",
          "options": {
            "A": "technological",
            "B": "physical",
            "C": "demographic",
            "D": "global"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q42",
          "sourceNumber": 42,
          "type": "multiple-choice",
          "prompt": "Acme Valves, Inc., has been a successful player in the oil field supply industry in the last 15 years. Acme maintained its strategy and product characteristics over this time period. However, the company has experienced declines in sales and profits over the last four quarters. The CEO of Acme should",
          "options": {
            "A": "continue with the proven strategy because its returns over the long run are important.",
            "B": "focus on improving efficiency of production and cost control.",
            "C": "conduct an analysis of the external environment.",
            "D": "immediately begin making incremental adjustments to the traditional business strategy in an effort to improve sales."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q43",
          "sourceNumber": 43,
          "type": "multiple-choice",
          "prompt": "The three parts of the external environment that affect a firm's strategic actions are:",
          "options": {
            "A": "economic, political, and legal.",
            "B": "general, industry, and competitor.",
            "C": "industry, business, and product.",
            "D": "local, national, and global."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q44",
          "sourceNumber": 44,
          "type": "multiple-choice",
          "prompt": "The ______ environment is composed of dimensions in the broader society that can influence an industry and the firms within it.",
          "options": {
            "A": "general",
            "B": "competitor",
            "C": "sociocultural",
            "D": "industry"
          },
          "answer": "A"
        },
        {
          "id": "ch2-q45",
          "sourceNumber": 45,
          "type": "multiple-choice",
          "prompt": "The environmental segments that make up the general environment typically will NOT include:",
          "options": {
            "A": "demographic factors.",
            "B": "sociocultural factors.",
            "C": "substitute products or services.",
            "D": "technological factors."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q46",
          "sourceNumber": 46,
          "type": "multiple-choice",
          "prompt": "Aardvark Corp. has three products. Two products together make up two-thirds of revenues and constitute 50 percent of company profits. Aardvark's third product makes up one-third of sales. With profitability far above the industry average, this product is responsible for one-half of Aardvark's profits. Which of the following statements regarding assessment of the general environment is accurate for Aardvark?",
          "options": {
            "A": "The company should monitor the general environment for changes that might affect the revenue of all products.",
            "B": "The company should monitor the general environment for changes that might affect the profitability of the most profitable products.",
            "C": "The company should monitor the general environment for changes that might affect the profitability of all products.",
            "D": "The company should monitor the general environment for changes that might affect the revenue and profitability of all products."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q47",
          "sourceNumber": 47,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT an activity used in the external environmental analysis process?",
          "options": {
            "A": "Scanning",
            "B": "Decrypting",
            "C": "Monitoring",
            "D": "Assessing"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q48",
          "sourceNumber": 48,
          "type": "multiple-choice",
          "prompt": "Environmental scanning would be most important for which of the following organizations?",
          "options": {
            "A": "A provider of hospice services for the terminally ill",
            "B": "A web design company catering to small businesses",
            "C": "A neighborhood sewer and water utility",
            "D": "A manufacturer of household linens"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q49",
          "sourceNumber": 49,
          "type": "multiple-choice",
          "prompt": "The use of the Internet by Netflix to collect data on customer preferences is an example of:",
          "options": {
            "A": "assessing.",
            "B": "monitoring.",
            "C": "forecasting.",
            "D": "scanning."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q50",
          "sourceNumber": 50,
          "type": "multiple-choice",
          "prompt": "When analysts develop feasible projections of future events and how quickly they will occur based on observed changes and trends, they are: engaged in",
          "options": {
            "A": "scanning.",
            "B": "monitoring.",
            "C": "forecasting.",
            "D": "assessing."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q51",
          "sourceNumber": 51,
          "type": "multiple-choice",
          "prompt": "A general environmental analysis can be expected to produce all of the following EXCEPT:",
          "options": {
            "A": "objective answers.",
            "B": "recognition of environmental trends.",
            "C": "identification of organizational opportunities.",
            "D": "identification of organizational threats."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q52",
          "sourceNumber": 52,
          "type": "multiple-choice",
          "prompt": "In analyzing the demographic segment of the general environment, one typically examines all of the following factors EXCEPT:",
          "options": {
            "A": "age structure.",
            "B": "ethnic mix.",
            "C": "distribution of income.",
            "D": "cultural values."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q53",
          "sourceNumber": 53,
          "type": "multiple-choice",
          "prompt": "Which of the following, identified in an analysis of the general environment, is an opportunity for an entrepreneur who wishes to open a business providing \"Fitness for Life\" physical conditioning services (strength, balance, and flexibility training) in a city of 100,000 people?",
          "options": {
            "A": "The average age of the population in his community is high.",
            "B": "The level of unemployment in his community is high.",
            "C": "A chiropractor and two independent physical therapists are located in his community.",
            "D": "The average education level of the population in his community is low."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q54",
          "sourceNumber": 54,
          "type": "multiple-choice",
          "prompt": "An analysis of income distribution would include all of the following EXCEPT:",
          "options": {
            "A": "the purchasing power of various age groups.",
            "B": "the discretionary income of various ethnic groups.",
            "C": "wage differentials between male and female employees working for a large manufacturer.",
            "D": "how income is distributed among regions of the United States."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q55",
          "sourceNumber": 55,
          "type": "multiple-choice",
          "prompt": "Demographic changes include variations in income distribution. Which of the following statements is true?",
          "options": {
            "A": "Firms are most interested in the consumers in the top 10 percent of household income.",
            "B": "In general, living standards have deteriorated over time.",
            "C": "The general loss in real income has been somewhat offset by the increase in dual-career couples.",
            "D": "Workforce diversity is making the concept of average income obsolete."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q56",
          "sourceNumber": 56,
          "type": "multiple-choice",
          "prompt": "The Obama administration sought to pursue policies that would:",
          "options": {
            "A": "remove the United States from NAFTA.",
            "B": "abolish antitrust laws.",
            "C": "increase the amount of work U.S. companies outsource to firms in other nations.",
            "D": "reduce the amount of work U.S. companies outsource to firms in other nations."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q57",
          "sourceNumber": 57,
          "type": "multiple-choice",
          "prompt": "An analysis of the economic segment of the external environment would include all of the following EXCEPT:",
          "options": {
            "A": "interest rates.",
            "B": "trade deficits or surpluses.",
            "C": "inflation rates.",
            "D": "income distribution."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q58",
          "sourceNumber": 58,
          "type": "multiple-choice",
          "prompt": "Characteristics of the current economic segment include all of the following EXCEPT:",
          "options": {
            "A": "general uncertainty.",
            "B": "a clear understanding of future economic opportunities and threats.",
            "C": "the inability of economists to provide valid and reliable predictions.",
            "D": "an expanding economy in Vietnam."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q59",
          "sourceNumber": 59,
          "type": "multiple-choice",
          "prompt": "The economic environment refers to:",
          "options": {
            "A": "the nature and direction of the economy in which a firm competes or may compete.",
            "B": "the economic outlook of the world provided by the World Bank.",
            "C": "an analysis of how the environmental movement and world economy interact.",
            "D": "an analysis of how new environmental regulations will affect the U.S. economy."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q60",
          "sourceNumber": 60,
          "type": "multiple-choice",
          "prompt": "Which of the following would NOT be identified in an analysis of the economic portion of the general environment?",
          "options": {
            "A": "The willingness of Chrysler's buyers to purchase large vehicles in light of an increase in oil prices",
            "B": "The ability of Ford to issue new debt in light of its recent financial performance",
            "C": "The ability of BMW's buyers to finance car purchases in light of a change in interest rates",
            "D": "The willingness of GM buyers to purchase new vehicles in light of the threat of recession"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q61",
          "sourceNumber": 61,
          "type": "multiple-choice",
          "prompt": "The political/legal segment of an environment represents:",
          "options": {
            "A": "the political preferences of different ethnic groups in the society.",
            "B": "the technological values of different political entities in society.",
            "C": "how organizations and governments mutually try to influence each other.",
            "D": "the system of regulations governments at all levels place on businesses."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q62",
          "sourceNumber": 62,
          "type": "multiple-choice",
          "prompt": "All of the following are aspects of the political/legal segment of the general environment EXCEPT:",
          "options": {
            "A": "lobby groups.",
            "B": "attitudes and values.",
            "C": "taxation laws.",
            "D": "industries chosen for deregulation."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q63",
          "sourceNumber": 63,
          "type": "multiple-choice",
          "prompt": "An analysis of society's attitudes and values would be conducted when studying the ______ segment of the general environment.",
          "options": {
            "A": "sociocultural",
            "B": "global",
            "C": "demographic",
            "D": "economic"
          },
          "answer": "A"
        },
        {
          "id": "ch2-q64",
          "sourceNumber": 64,
          "type": "multiple-choice",
          "prompt": "In a suburban community outside a city in Alabama, a retail store opened that specialized in dancewear for children and adults. It was moderately successful for five years until the local newspaper published an exposé that scanty lingerie stocked in the back of the store's showroom was selling briskly to a certain clientele. Afterward, the store lost most of its customers and nearly closed. Which segment of the environment did the store owners fail to take into account when they began selling the lingerie?",
          "options": {
            "A": "the sociocultural segment",
            "B": "the economic segment",
            "C": "the demographic segment",
            "D": "the political/legal segment"
          },
          "answer": "A"
        },
        {
          "id": "ch2-q65",
          "sourceNumber": 65,
          "type": "multiple-choice",
          "prompt": "The technological segment of environmental analysis includes:",
          "options": {
            "A": "institutions and activities involved with creating new knowledge and translating that knowledge into new outputs.",
            "B": "the determination of when machinery will need to be replaced in a given firm.",
            "C": "the need for new technology used by a firm to gain a competitive advantage.",
            "D": "places where a firm's technology will allow that firm to dominate a given market."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q66",
          "sourceNumber": 66,
          "type": "multiple-choice",
          "prompt": "Understanding how new knowledge can develop new products, processes, or materials is a result of analyzing the ______ segment of the general environment.",
          "options": {
            "A": "economic",
            "B": "political/legal",
            "C": "technological",
            "D": "global"
          },
          "answer": "C"
        },
        {
          "id": "ch2-q67",
          "sourceNumber": 67,
          "type": "multiple-choice",
          "prompt": "The next critical technological opportunity for organizations is predicted to be:",
          "options": {
            "A": "the Internet.",
            "B": "multiphasic interventions.",
            "C": "biological engineering.",
            "D": "wireless communications."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q68",
          "sourceNumber": 68,
          "type": "multiple-choice",
          "prompt": "Which of the following would be an example of the application of the next major technological opportunity for organizations?",
          "options": {
            "A": "Boeing's 747",
            "B": "Toyota's hybrid vehicles",
            "C": "Budweiser’s non-alcoholic beer",
            "D": "SpaceX’s reusable space vehicle"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q69",
          "sourceNumber": 69,
          "type": "multiple-choice",
          "prompt": "The observation that China reached automotive production overcapacity in 2015, and has a glut of extra cars, is an aspect of the ______ segment of the general environment.",
          "options": {
            "A": "demographic",
            "B": "global",
            "C": "physical",
            "D": "technological"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q70",
          "sourceNumber": 70,
          "type": "multiple-choice",
          "prompt": "Because of threats and risks in the global environment, some firms choose to take a more cautious approach by:",
          "options": {
            "A": "avoiding global markets altogether.",
            "B": "expanding only to developed countries.",
            "C": "focusing on global niche markets.",
            "D": "acquiring already established firms in foreign markets."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q71",
          "sourceNumber": 71,
          "type": "multiple-choice",
          "prompt": "The concepts of Guanxi, Wa, and Inhwa all convey the general idea of:",
          "options": {
            "A": "entrepreneurial risk-taking.",
            "B": "interpersonal relationships.",
            "C": "the value of hard work.",
            "D": "personal achievement."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q72",
          "sourceNumber": 72,
          "type": "multiple-choice",
          "prompt": "Global warming and energy consumption trends are aspects of the ______ segment of the general environment that firms should monitor.",
          "options": {
            "A": "technological",
            "B": "physical",
            "C": "sociocultural",
            "D": "economic"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q73",
          "sourceNumber": 73,
          "type": "multiple-choice",
          "prompt": "Green design, sustainable packaging, waste management, and energy efficiency are aspects of the ______ segment of the general environment that companies have sought to address with environmental sustainability initiatives.",
          "options": {
            "A": "technological",
            "B": "political/legal",
            "C": "global",
            "D": "physical"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q74",
          "sourceNumber": 74,
          "type": "multiple-choice",
          "prompt": "All of the following are examples of efforts by firms to address the physical segment of the general:",
          "options": {
            "A": "development of sustainable packaging by McDonald's.",
            "B": "reduction in carbon dioxide emissions by Procter & Gamble.",
            "C": "reduction in water usage in plants by Unilever.",
            "D": "increase in hiring of women and minorities at Microsoft."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q75",
          "sourceNumber": 75,
          "type": "multiple-choice",
          "prompt": "One popular approach to taking care of the physical environment is:",
          "options": {
            "A": "producing and selling additional green products.",
            "B": "lobbying the government to reduce environmental regulations.",
            "C": "making donations to the Sierra Club and other environmental organizations.",
            "D": "increasing health benefits for employees."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q76",
          "sourceNumber": 76,
          "type": "multiple-choice",
          "prompt": "An industry is defined as:",
          "options": {
            "A": "a group of firms producing the same products or services.",
            "B": "firms producing items that sell through the same distribution channels.",
            "C": "firms that sell the same products or services to the same customer base.",
            "D": "a group of firms producing products that are close substitutes."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q77",
          "sourceNumber": 77,
          "type": "multiple-choice",
          "prompt": "The likelihood of entry of new competitors is affected by ______ and ______.",
          "options": {
            "A": "barriers to entry; expected retaliation of current industry organizations",
            "B": "the power of existing suppliers; buyers",
            "C": "the profitability of the industry; the market share of its leading firm",
            "D": "the demand for the product; the profitability of the competitors"
          },
          "answer": "A"
        },
        {
          "id": "ch2-q78",
          "sourceNumber": 78,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT an entry barrier to an industry?",
          "options": {
            "A": "Expected competitor retaliation",
            "B": "Economies of scale",
            "C": "Customer product loyalty",
            "D": "Bargaining power of suppliers"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q79",
          "sourceNumber": 79,
          "type": "multiple-choice",
          "prompt": "New entrants to an industry are more likely when:",
          "options": {
            "A": "it is difficult to gain access to distribution channels.",
            "B": "economies of scale in the industry are high.",
            "C": "product differentiation in the industry is low.",
            "D": "capital requirements in the industry are high."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q80",
          "sourceNumber": 80,
          "type": "multiple-choice",
          "prompt": "Economies of scale refers to the fact that as the:",
          "options": {
            "A": "quantity of product produced in a given time period increases, the cost of manufacturing each unit increases.",
            "B": "quantity of product produced in a given time period increases, the cost of manufacturing each unit remains constant.",
            "C": "quantity of product produced in a given time period increases, the cost of manufacturing each unit decreases.",
            "D": "quantity of product produced in a given time period decreases, the cost of manufacturing each unit decreases."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q81",
          "sourceNumber": 81,
          "type": "multiple-choice",
          "prompt": "The large amount of advertising by firms such as Procter & Gamble and Colgate-Palmolive is an example of what kind of barrier to entry?",
          "options": {
            "A": "Access to distribution channels",
            "B": "Capital requirements",
            "C": "Economies of scale",
            "D": "Product differentiation"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q82",
          "sourceNumber": 82,
          "type": "multiple-choice",
          "prompt": "Product differentiation refers to the:",
          "options": {
            "A": "ability of the buyer of a product to negotiate a lower price.",
            "B": "response of incumbent firms to new entrants.",
            "C": "belief by customers that a product is unique.",
            "D": "fact that as more of a product is produced the cheaper it becomes per unit."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q83",
          "sourceNumber": 83,
          "type": "multiple-choice",
          "prompt": "When consumers change mobile phone and data service providers, they may be required to maintain service with the provider for a specified time period. This is an example of a:",
          "options": {
            "A": "cost to a producer to exchange equipment in a facility when new technologies emerge.",
            "B": "cost of changing the firm's strategic group.",
            "C": "one-time cost suppliers incur when selling to a different customer.",
            "D": "one-time cost customers incur when buying from a different supplier."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q84",
          "sourceNumber": 84,
          "type": "multiple-choice",
          "prompt": "Customer loyalty programs such as airline frequent-flyer miles are an attempt to:",
          "options": {
            "A": "decrease competitors' access to distribution channels.",
            "B": "develop a cost advantage independent of scale.",
            "C": "increase customers' switching costs.",
            "D": "overcome the perishability of the hotel \"product.\""
          },
          "answer": "C"
        },
        {
          "id": "ch2-q85",
          "sourceNumber": 85,
          "type": "multiple-choice",
          "prompt": "As customers come to believe that a firm's product is unique, this allows the firm to:",
          "options": {
            "A": "decrease its advertising expenditures.",
            "B": "customize its product.",
            "C": "force other companies out of the market by lowering prices.",
            "D": "obtain loyal customers."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q86",
          "sourceNumber": 86,
          "type": "multiple-choice",
          "prompt": "DWK Foods has developed a line of cookies and candies sweetened exclusively with organic honey. Although DWK is selling some of the products over the Internet, in order to gain economies of scale the products must be sold in retail outlets as well. The main barrier to entry DWK is likely to encounter here is:",
          "options": {
            "A": "government licensing and permits.",
            "B": "access to distribution channels.",
            "C": "consumers' switching costs.",
            "D": "cost disadvantages independent of scale."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q87",
          "sourceNumber": 87,
          "type": "multiple-choice",
          "prompt": "For a restaurant business dependent on drive-thru customers, the major cost disadvantage independent of scale would be if:",
          "options": {
            "A": "favorable locations are not available.",
            "B": "other competitors have proprietary product technology.",
            "C": "access to food and ingredients is difficult.",
            "D": "other competitors have government subsidies."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q88",
          "sourceNumber": 88,
          "type": "multiple-choice",
          "prompt": "A certain marble quarry provides a unique type of marble that is richly colored and strikingly veined. It has been used for churches and public buildings throughout the world. The architect of a new headquarters for a prestigious Fortune 500 firm has specified the use of this marble, and this marble only, for the project. Which of the following statements is most likely to be true?",
          "options": {
            "A": "The cost of the marble will be expensive because of the bargaining power of the supplier.",
            "B": "The cost of the marble will be moderate because of the bargaining power of the buyer.",
            "C": "The cost of the marble will be moderate because of economies of scale.",
            "D": "The cost of the marble will be expensive because of the high strategic stakes involved."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q89",
          "sourceNumber": 89,
          "type": "multiple-choice",
          "prompt": "Suppliers are powerful when:",
          "options": {
            "A": "satisfactory substitutes are available.",
            "B": "they sell a commodity product.",
            "C": "they offer a credible threat of forward integration.",
            "D": "they are in a highly fragmented industry."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q90",
          "sourceNumber": 90,
          "type": "multiple-choice",
          "prompt": "How is consolidation among fuel providers serving airport facilities viewed in the five forces model of competition?",
          "options": {
            "A": "As a reduction of the airlines' ability to benefit from economies of scale.",
            "B": "As an increase in switching costs because the airlines have no choice but to use jet fuel and other oil products.",
            "C": "As an increase in the bargaining power of suppliers of a critical input.",
            "D": "As an increase in the intensity of rivalry among airlines for scarce resources."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q91",
          "sourceNumber": 91,
          "type": "multiple-choice",
          "prompt": "Blood banks are highly dependent on donors. In the terminology of industry analysis, which statement about donors is accurate?",
          "options": {
            "A": "Blood donors are suppliers and are powerful because of the critical nature of what they provide to the blood bank.",
            "B": "Blood donors are suppliers and are powerful because of their concentration relative to the blood bank.",
            "C": "Blood donors are buyers and are not powerful because switching costs to change to alternative inputs are low.",
            "D": "Blood donors are buyers and are powerful because of the volume of blood needed."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q92",
          "sourceNumber": 92,
          "type": "multiple-choice",
          "prompt": "The aircraft industry has long been dominated by two large aircraft manufacturers, Boeing and Airbus. The demand for major aircraft is low, and Boeing and Airbus aggressively compete for orders from airlines. What effect will these conditions have on the domestic airline industry?",
          "options": {
            "A": "It will make the airline industry more attractive because of decreased supplier power.",
            "B": "It will make the airline industry less attractive because of decreased supplier power.",
            "C": "It will make the airline industry more attractive because of increased supplier power.",
            "D": "It will make the airline industry more attractive because of a new entrant."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q93",
          "sourceNumber": 93,
          "type": "multiple-choice",
          "prompt": "Golden Lotus, an exercise club targeting healthy individuals over 50, is located in a fast-growing city in the Southwest. Which of the following factors that may have an effect on the success of Golden Lotus is the most directly controllable by the company?",
          "options": {
            "A": "The sociocultural environment",
            "B": "The demographics of the environment",
            "C": "The economy of the local area",
            "D": "The power of the customers/buyers"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q94",
          "sourceNumber": 94,
          "type": "multiple-choice",
          "prompt": "Buyers are powerful when:",
          "options": {
            "A": "there is a threat of forward integration.",
            "B": "they purchase a small proportion of the supplier's output.",
            "C": "switching costs are low.",
            "D": "the buyers' industry is fragmented."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q95",
          "sourceNumber": 95,
          "type": "multiple-choice",
          "prompt": "The highest amount a firm can charge for its products is most directly affected by:",
          "options": {
            "A": "expected retaliation from competitors.",
            "B": "the cost of substitute products.",
            "C": "variable costs of production.",
            "D": "customers' high switching costs."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q96",
          "sourceNumber": 96,
          "type": "multiple-choice",
          "prompt": "The threat from substitutes is high when:",
          "options": {
            "A": "switching costs are high.",
            "B": "the substitute product's price is lower than the industry product's price.",
            "C": "the quality of the substitute product is lower than the quality of the industry's product.",
            "D": "the substitute product stimulates new process innovations within the industry."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q97",
          "sourceNumber": 97,
          "type": "multiple-choice",
          "prompt": "Media content has moved from paper, tape, and film to a digital world based on Internet technology. From the perspective of the five forces model, which force is most relevant here?",
          "options": {
            "A": "Buyers",
            "B": "Substitutes",
            "C": "Entry barriers",
            "D": "Suppliers"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q98",
          "sourceNumber": 98,
          "type": "multiple-choice",
          "prompt": "All of the following are forces that create high rivalry within an industry EXCEPT:",
          "options": {
            "A": "numerous or equally balanced competitors.",
            "B": "high fixed costs.",
            "C": "fast industry growth.",
            "D": "high storage costs."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q99",
          "sourceNumber": 99,
          "type": "multiple-choice",
          "prompt": "High-level maintenance on aircraft is performed by the manufacturer. This service after the sale means that in the aircraft industry:",
          "options": {
            "A": "customers are relatively weak because of the high switching costs created by frequent-flyer programs.",
            "B": "the industry is moving toward differentiation of services.",
            "C": "the competitive rivalry in the industry is severe.",
            "D": "the economic segment of the external environment has shifted, but airline strategies have not changed."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q100",
          "sourceNumber": 100,
          "type": "multiple-choice",
          "prompt": "A manufacturer of washing machines has expanded its plant and has created excess capacity, just as the general economy has taken a downturn. The company is likely to:",
          "options": {
            "A": "raise prices on washing machines to offset lost sales.",
            "B": "be vulnerable to new entrants to an attractive market.",
            "C": "suffer from intense rivalry from international manufacturers.",
            "D": "offer rebates and incentives for customers who purchase washing machines."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q101",
          "sourceNumber": 101,
          "type": "multiple-choice",
          "prompt": "When rival firms compete aggressively by trying to attract competitors' customers, this might be an indication of:",
          "options": {
            "A": "an industry with low exit barriers.",
            "B": "increasing economies of scale.",
            "C": "slow industry growth.",
            "D": "high bargaining power among buyers."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q102",
          "sourceNumber": 102,
          "type": "multiple-choice",
          "prompt": "Mighty Green, a residential lawn chemical manufacturer, is committed to gaining market share in its industry. Mighty Green:",
          "options": {
            "A": "is likely to raise the level of competitive rivalry in the industry.",
            "B": "probably has top management who are affected by emotional barriers to exit.",
            "C": "has decided that long-run above-average returns are not important.",
            "D": "will probably embark on an acquisition strategy."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q103",
          "sourceNumber": 103,
          "type": "multiple-choice",
          "prompt": "Which of the following explains, in part, why rivalry among McDonald's, Wendy's, and Burger King is intense?",
          "options": {
            "A": "There is low geographic saturation of the market.",
            "B": "There is high differentiation among competing products.",
            "C": "The threat of supplier forward integration is low.",
            "D": "These companies are trying to find ways to differentiate their products."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q104",
          "sourceNumber": 104,
          "type": "multiple-choice",
          "prompt": "Circuit Inc. is a manufacturer of a broad range of consumer electronics products. These consumer products are all highly profitable. The firm also manufactures a low-cost component that is an essential differentiating feature for most of its consumer products. The costs to manufacture this component have risen sharply in recent months. Internal estimates now indicate the company is breaking even on the manufacture of this component. Which of the following is most likely?",
          "options": {
            "A": "Circuit will likely continue to manufacture the component, even at a loss, due to low supplier power.",
            "B": "Circuit will likely continue to manufacture the component, even at a loss, due to high strategic stakes.",
            "C": "Circuit will likely discontinue manufacture of the component due to low strategic stakes.",
            "D": "Circuit will likely discontinue manufacture of the component due to high supplier stakes."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q105",
          "sourceNumber": 105,
          "type": "multiple-choice",
          "prompt": "Exit barriers to a firm include all of the following EXCEPT:",
          "options": {
            "A": "generic assets.",
            "B": "loyalty to employees.",
            "C": "governmental concern about job loss.",
            "D": "restrictive labor agreements."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q106",
          "sourceNumber": 106,
          "type": "multiple-choice",
          "prompt": "An owner of a stable of racehorses has been earning below-average returns for more than 15 years. To a colleague, he expressed his determination to stay in horse racing until he died because \"racing is in my blood.\" This individual is probably still racing horses because of:",
          "options": {
            "A": "high barriers to exit.",
            "B": "high switching costs.",
            "C": "high fixed costs.",
            "D": "low levels of competitive rivalry."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q107",
          "sourceNumber": 107,
          "type": "multiple-choice",
          "prompt": "According to the five forces model, an attractive industry would have all of the following characteristics EXCEPT:",
          "options": {
            "A": "low barriers to entry.",
            "B": "suppliers and buyers with little bargaining power.",
            "C": "a moderate degree of rivalry among competitors.",
            "D": "few good product substitutes."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q108",
          "sourceNumber": 108,
          "type": "multiple-choice",
          "prompt": "According to the five forces model, an unattractive industry would include all of the following characteristics EXCEPT:",
          "options": {
            "A": "low economies of scale needed for new firms to enter.",
            "B": "low supplier power due to commodity inputs.",
            "C": "high threat of substitute products due to a large number of low-cost alternatives.",
            "D": "high bargaining power of buyers due to low switching costs."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q109",
          "sourceNumber": 109,
          "type": "multiple-choice",
          "prompt": "The competition within each strategic group is:",
          "options": {
            "A": "more intense than the competition between strategic groups.",
            "B": "less intense than the competition between strategic groups.",
            "C": "typically very low.",
            "D": "an unknown factor in the analysis of competitive practices within a firm's strategic group."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q110",
          "sourceNumber": 110,
          "type": "multiple-choice",
          "prompt": "Firms within strategic groups:",
          "options": {
            "A": "follow dissimilar strategies.",
            "B": "follow similar strategies across certain dimensions.",
            "C": "typically engage in greater intergroup rivalry than intragroup rivalry.",
            "D": "exist almost exclusively in the manufacturing sector."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q111",
          "sourceNumber": 111,
          "type": "multiple-choice",
          "prompt": "All of the following are implications of strategic groups EXCEPT:",
          "options": {
            "A": "the strength of the five forces differs across strategic groups.",
            "B": "the strength of the five forces is the same across strategic groups.",
            "C": "competitive rivalry within strategic groups is greater than between strategic groups.",
            "D": "the closer the strategic groups are in terms of strategies, the greater is the likelihood of rivalry."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q112",
          "sourceNumber": 112,
          "type": "multiple-choice",
          "prompt": "Competitor analysis focuses on:",
          "options": {
            "A": "firms with which the company competes directly.",
            "B": "firms that produce products that are substitutes.",
            "C": "all firms in the industry.",
            "D": "companies that might enter the industry."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q113",
          "sourceNumber": 113,
          "type": "multiple-choice",
          "prompt": "Which of the following pairs of companies would be least likely to be examined together as part of competitive analysis?",
          "options": {
            "A": "Wendy's and Taco Bell",
            "B": "Samsung and Apple",
            "C": "Netflix and Microsoft",
            "D": "Coca-Cola and PepsiCo"
          },
          "answer": "C"
        },
        {
          "id": "ch2-q114",
          "sourceNumber": 114,
          "type": "multiple-choice",
          "prompt": "Competitor intelligence is:",
          "options": {
            "A": "legally or illegally gained data about competitors' internal strategic processes and competitive decisions.",
            "B": "strategic information gained from industrial espionage targeting international competitors.",
            "C": "the data that the firm gathers to understand competitors' objectives, strategies, assumptions, and capabilities.",
            "D": "illegal to gather under the Sarbanes-Oxley Act."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q115",
          "sourceNumber": 115,
          "type": "multiple-choice",
          "prompt": "Once a firm has determined its competitors' future objectives, current strategy, assumptions, and strengths and weaknesses, its next step is to develop:",
          "options": {
            "A": "an environmental assessment.",
            "B": "a marketing plan.",
            "C": "a response profile.",
            "D": "a task force to implement the plan."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q116",
          "sourceNumber": 116,
          "type": "multiple-choice",
          "prompt": "A competitor analysis includes all of the following about competitors EXCEPT:",
          "options": {
            "A": "future objectives.",
            "B": "current strategy.",
            "C": "assumptions.",
            "D": "traditions."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q117",
          "sourceNumber": 117,
          "type": "multiple-choice",
          "prompt": "Clarissa is a sales representative for a large pharmaceutical firm. While calling on one of her major clients, the purchasing director of a hospital, the client told her confidential information that a sales representative from a competing firm had passed on to him. The information completely contradicts Clarissa's firm's understanding of the competitor's business strategy and would allow Clarissa's employer to gain many of the competitor's clients. What ethical implications may result from this situation?",
          "options": {
            "A": "There is no ethical or legal concern here for Clarissa.",
            "B": "The ethical dilemma is not Clarissa's but her client's, since he passed on confidential information to her voluntarily.",
            "C": "The ethical dilemma here is the right of competitors not to reveal certain information.",
            "D": "This is an example of ethical competitor intelligence obtained as eavesdropping."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q118",
          "sourceNumber": 118,
          "type": "multiple-choice",
          "prompt": "All of the following are ethical sources of data for external analysis EXCEPT:",
          "options": {
            "A": "trade shows.",
            "B": "a competitor's annual reports.",
            "C": "a competitor's help-wanted advertisements.",
            "D": "a competitor's confidential memos."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q119",
          "sourceNumber": 119,
          "type": "multiple-choice",
          "prompt": "Competitor intelligence could ethically come from all of the following EXCEPT:",
          "options": {
            "A": "court records.",
            "B": "financial reports.",
            "C": "trade show discussions.",
            "D": "eavesdropping."
          },
          "answer": "D"
        },
        {
          "id": "ch2-q120",
          "sourceNumber": 120,
          "type": "multiple-choice",
          "prompt": "Which of the following represents a competitive intelligence practice that is both legal and ethical?",
          "options": {
            "A": "A firm hires a competitor's employees and asks them to share the names and addresses of business contacts from their previous company.",
            "B": "An executive attends a trade show solely to obtain a competitor's brochures, listen to sales pitches, and ask questions about the competitor's products.",
            "C": "A city council member shares information about the decision process for selecting a contractor to build a new city council building with his wife, an executive with a construction firm bidding on the contract.",
            "D": "A marketing manager sells confidential plans for a company's expansion into the Far East to a firm that is not a direct competitor."
          },
          "answer": "B"
        },
        {
          "id": "ch2-q121",
          "sourceNumber": 121,
          "type": "multiple-choice",
          "prompt": "Which of the following intelligence-gathering techniques is most likely to be legal and ethical?",
          "options": {
            "A": "Hiring investigators to examine the competitor's trash",
            "B": "Entering a competitor's production plant without authorization",
            "C": "Redirecting a competitor's emails to one's own company",
            "D": "Attending trade show presentations given by a competitor's employees"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q122",
          "sourceNumber": 122,
          "type": "multiple-choice",
          "prompt": "The U.S. Hispanic market is the third-largest \"Latin American\" economy behind Brazil and Mexico. This impacts the ______ aspect of demographic segment analysis.",
          "options": {
            "A": "age structure",
            "B": "geographic distribution",
            "C": "income distribution",
            "D": "ethnic mix"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q123",
          "sourceNumber": 123,
          "type": "multiple-choice",
          "prompt": "New Jersey and New York have the highest state taxes in the United States. They also have high ratios of people moving out compared to people moving into the state. This impacts the ______ aspect of demographic analysis.",
          "options": {
            "A": "age structure",
            "B": "geographic distribution",
            "C": "income distribution",
            "D": "ethnic mix"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q124",
          "sourceNumber": 124,
          "type": "multiple-choice",
          "prompt": "The communications industry is broadly defined as encompassing all of the following EXCEPT:",
          "options": {
            "A": "media companies.",
            "B": "smartphone producers.",
            "C": "book retailers.",
            "D": "entertainment companies."
          },
          "answer": "C"
        },
        {
          "id": "ch2-q125",
          "sourceNumber": 125,
          "type": "multiple-choice",
          "prompt": "The Department of Defense buys aircraft from U.S. companies for national security reasons. This is an example of a ______ barrier to entry.",
          "options": {
            "A": "cost disadvantage independent of scale",
            "B": "government policy",
            "C": "capital requirements",
            "D": "product differentiation"
          },
          "answer": "B"
        },
        {
          "id": "ch2-q126",
          "sourceNumber": 126,
          "type": "multiple-choice",
          "prompt": "After Amazon lowered the price on its tablets, Samsung eventually lowered the price on its tablets. Samsung needed to do this because:",
          "options": {
            "A": "it is in the same strategic group.",
            "B": "it is outside the strategic group.",
            "C": "of inter-strategic group competition.",
            "D": "of strategic distinctiveness."
          },
          "answer": "A"
        },
        {
          "id": "ch2-q127",
          "sourceNumber": 127,
          "type": "multiple-choice",
          "prompt": "Applications developed for iPhones make the phone more valuable to iPhone users. App developers are ______ to Apple.",
          "options": {
            "A": "suppliers",
            "B": "customers",
            "C": "competitors",
            "D": "complementors"
          },
          "answer": "D"
        },
        {
          "id": "ch2-q128",
          "sourceNumber": 128,
          "type": "multiple-choice",
          "prompt": "Counterfeiting goods and exporting them from China is:",
          "options": {
            "A": "ethical and legal.",
            "B": "unethical but legal.",
            "C": "ethical but illegal.",
            "D": "unethical and illegal."
          },
          "answer": "D"
        }
      ]
    },
    {
      "number": 3,
      "title": "Chapter 3 The Internal Organization: Resources, Capabilities, Core Competencies, and Competitive Advantages",
      "questions": [
        {
          "id": "ch3-q40",
          "sourceNumber": 40,
          "type": "multiple-choice",
          "prompt": "All competitive advantages have:",
          "options": {
            "A": "a limited life.",
            "B": "an expiration date.",
            "C": "the ability to earn above-average returns indefinitely.",
            "D": "the ability to lead to more competitive advantages."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q41",
          "sourceNumber": 41,
          "type": "multiple-choice",
          "prompt": "It is increasingly difficult for a firm to develop and sustain a competitive advantage because of the effects of globalization and:",
          "options": {
            "A": "the rapid development of the Internet's capabilities.",
            "B": "extensive use of outsourcing within the borders of the United States.",
            "C": "the declining number of inventions and patents developed by U.S. citizens.",
            "D": "the simultaneous erosion of the U.S. work ethic and the U.S. education system."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q42",
          "sourceNumber": 42,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT required for a firm to achieve strategic competitiveness and earn above-average returns from its core competencies?",
          "options": {
            "A": "Core competencies must be acquired.",
            "B": "Core competencies must be bundled.",
            "C": "Core competencies must be internationalized.",
            "D": "Core competencies must be leveraged."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q43",
          "sourceNumber": 43,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT a factor affecting sustainability of a competitive advantage?",
          "options": {
            "A": "the availability of substitutes for a firm's core competence",
            "B": "the rate at which obsolescence of the core competence occurs because of environmental changes",
            "C": "the imitability of a core competence",
            "D": "the length of time the core competence has existed"
          },
          "answer": "D"
        },
        {
          "id": "ch3-q44",
          "sourceNumber": 44,
          "type": "multiple-choice",
          "prompt": "Internal analysis enables a firm to determine what the firm:",
          "options": {
            "A": "can do.",
            "B": "should do.",
            "C": "will do.",
            "D": "might do."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q45",
          "sourceNumber": 45,
          "type": "multiple-choice",
          "prompt": "The proper matching of what a firm can do with what it might do:",
          "options": {
            "A": "balances the internal characteristics of the firm with the characteristics of the external environment.",
            "B": "overcomes the rigidity and inertia resulting from a history of success.",
            "C": "yields insights the firm requires to select its strategy.",
            "D": "develops core competencies based on human knowledge."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q46",
          "sourceNumber": 46,
          "type": "multiple-choice",
          "prompt": "The key to achieving competitiveness, earning above-average returns, and remaining ahead of competitors in the long run is to manage current core competencies:",
          "options": {
            "A": "in a way that uniquely bundles and leverages the firm's existing resources.",
            "B": "while simultaneously developing new ones.",
            "C": "and imitate the core competencies of successful competitors.",
            "D": "in order to preserve and enhance them against the firm's competitors."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q47",
          "sourceNumber": 47,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT a component of internal analysis leading to competitive advantage?",
          "options": {
            "A": "Tangible and intangible resources",
            "B": "Analysis of supplier power",
            "C": "Capabilities",
            "D": "Core competencies"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q48",
          "sourceNumber": 48,
          "type": "multiple-choice",
          "prompt": "Value consists of:",
          "options": {
            "A": "a product's proprietary characteristics and attributes for which customers are willing to pay.",
            "B": "a product's performance characteristics and attributes for which customers are willing to pay.",
            "C": "a product's proprietary characteristics and attributes for which customers consider paying.",
            "D": "a product's performance characteristics and attributes for which customers consider paying."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q49",
          "sourceNumber": 49,
          "type": "multiple-choice",
          "prompt": "______ are the source of a firm's ______, which are the source of the firm's ______.",
          "options": {
            "A": "Resources; capabilities; core competencies",
            "B": "Capabilities; resources; core competencies",
            "C": "Capabilities; resources; above-average returns",
            "D": "Core competencies; resources; competitive advantage"
          },
          "answer": "A"
        },
        {
          "id": "ch3-q50",
          "sourceNumber": 50,
          "type": "multiple-choice",
          "prompt": "______ is measured by a product's performance characteristics and its attributes for which customers are willing to pay.",
          "options": {
            "A": "Competitive advantage",
            "B": "Profit potential",
            "C": "Contribution",
            "D": "Value"
          },
          "answer": "D"
        },
        {
          "id": "ch3-q51",
          "sourceNumber": 51,
          "type": "multiple-choice",
          "prompt": "By emphasizing core competencies when formulating strategies, companies learn to compete primarily on the basis of:",
          "options": {
            "A": "intangible resources.",
            "B": "their primary activities.",
            "C": "firm-specific differences.",
            "D": "efficiency of production."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q52",
          "sourceNumber": 52,
          "type": "multiple-choice",
          "prompt": "The challenge and difficulty of making effective decisions are implied by preliminary evidence that ______ of organizational decisions fail.",
          "options": {
            "A": "one-fourth",
            "B": "one-fifth",
            "C": "one-tenth",
            "D": "one-half"
          },
          "answer": "D"
        },
        {
          "id": "ch3-q53",
          "sourceNumber": 53,
          "type": "multiple-choice",
          "prompt": "A decision that results in failure:",
          "options": {
            "A": "is a career-ending event because it is so unusual.",
            "B": "often results from lack of accountability.",
            "C": "fosters organizational inertia.",
            "D": "allows for learning."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q54",
          "sourceNumber": 54,
          "type": "multiple-choice",
          "prompt": "The three conditions that characterize difficult managerial decisions concerning resources, capabilities, and core competencies are",
          "options": {
            "A": "complexity, rarity, and human intellectual capital.",
            "B": "uncertainty, complexity, and intraorganizational conflicts.",
            "C": "imitability, complexity, and interorganizational conflicts.",
            "D": "imitability, comparability, and human intellectual capital."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q55",
          "sourceNumber": 55,
          "type": "multiple-choice",
          "prompt": "A person who has made a successful decision when no obviously correct model or rule is available or when relevant data are unreliable or incomplete has exercised:",
          "options": {
            "A": "foresight.",
            "B": "judgment.",
            "C": "effective strategic thinking.",
            "D": "decisiveness."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q56",
          "sourceNumber": 56,
          "type": "multiple-choice",
          "prompt": "One reason executive judgment can be a particularly important source of competitive advantage is that judgment:",
          "options": {
            "A": "allows a firm to build a strong reputation.",
            "B": "gains the loyalty of shareholders.",
            "C": "increases human intellectual capacity.",
            "D": "allows for superior bundling of resources."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q57",
          "sourceNumber": 57,
          "type": "multiple-choice",
          "prompt": "Judgment is the capacity for making a successful decision when:",
          "options": {
            "A": "there are multiple decision criteria.",
            "B": "no obviously correct model or rule is available.",
            "C": "cognitive biases create barriers to rationality.",
            "D": "there are contradictions between the firm's vision and its implemented strategy."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q58",
          "sourceNumber": 58,
          "type": "multiple-choice",
          "prompt": "The most numerous of the following organizational characteristics are:",
          "options": {
            "A": "resources.",
            "B": "capacities.",
            "C": "capabilities.",
            "D": "core competencies."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q59",
          "sourceNumber": 59,
          "type": "multiple-choice",
          "prompt": "Capabilities typically come from:",
          "options": {
            "A": "individual resources.",
            "B": "one unique resource.",
            "C": "several outstanding resources used independently.",
            "D": "combining resources."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q60",
          "sourceNumber": 60,
          "type": "multiple-choice",
          "prompt": "All of the following are tangible resources EXCEPT:",
          "options": {
            "A": "production equipment.",
            "B": "distribution centers.",
            "C": "a firm's reputation.",
            "D": "formal reporting structures."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q61",
          "sourceNumber": 61,
          "type": "multiple-choice",
          "prompt": "Tangible resources include:",
          "options": {
            "A": "assets that are people-dependent, such as know-how.",
            "B": "assets that can be observed and quantified.",
            "C": "organizational culture.",
            "D": "a firm's reputation."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q62",
          "sourceNumber": 62,
          "type": "multiple-choice",
          "prompt": "Compared to intangible resources, tangible resources are ______ constrained because they are ______ to leverage.",
          "options": {
            "A": "less; easier",
            "B": "less; harder",
            "C": "more; harder",
            "D": "more; easier"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q63",
          "sourceNumber": 63,
          "type": "multiple-choice",
          "prompt": "Compared to tangible resources, intangible resources are:",
          "options": {
            "A": "of less strategic value to the firm.",
            "B": "less likely to be the focus of strategic analysis.",
            "C": "a superior source of capabilities.",
            "D": "more likely to be reflected on the firm's balance sheet."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q64",
          "sourceNumber": 64,
          "type": "multiple-choice",
          "prompt": "Compared to tangible resources, intangible resources are ______ and ______.",
          "options": {
            "A": "less visible; more difficult to copy.",
            "B": "less visible; less difficult to copy.",
            "C": "more visible; more difficult to copy.",
            "D": "more visible; less difficult to copy."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q65",
          "sourceNumber": 65,
          "type": "multiple-choice",
          "prompt": "The critical executive skill of the current business age is the ability to:",
          "options": {
            "A": "manage technological innovation.",
            "B": "manage human intellect.",
            "C": "initiate change and overcome inertia.",
            "D": "coordinate tangible and intangible resources."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q66",
          "sourceNumber": 66,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT a reputational resource?",
          "options": {
            "A": "Customers' opinions that the firm's products are high quality",
            "B": "Employees' opinions of the firm as a terrible place to work",
            "C": "Suppliers' opinions that the firm pays its bills in a timely manner",
            "D": "Customers' opinions that using the firm's products makes them attractive"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q67",
          "sourceNumber": 67,
          "type": "multiple-choice",
          "prompt": "An investor is considering buying a restaurant that has been in operation for a number of years. The restaurant has a highly regarded chef and many long-term kitchen and wait staff who work together smoothly. It has a reputation for dishes of consistently high quality and an appealing dining atmosphere. What should the investor consider when making a decision?",
          "options": {
            "A": "The investor will find that the success of this restaurant is so heavily based on human resources that the business will likely be subject to inertia in the future.",
            "B": "The investor will find that the restaurant's financial statements undervalue the true value of its resources.",
            "C": "The investor should be aware that intangible assets are difficult to leverage into additional businesses.",
            "D": "The investor should search for a firm that has competitive advantages based on tangible resources."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q68",
          "sourceNumber": 68,
          "type": "multiple-choice",
          "prompt": "Which of the following is a true statement about capabilities?",
          "options": {
            "A": "Capabilities are often developed in specific functional areas such as manufacturing, R&D, and marketing.",
            "B": "Valuable capabilities are based almost entirely on tangible resources.",
            "C": "Capabilities based on human capital are more vulnerable to obsolescence than other intangible capabilities because of the tendency for employee knowledge to become outdated.",
            "D": "The link between firm financial performance and capabilities is dependent on whether the capabilities are based on tangible or intangible resources."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q69",
          "sourceNumber": 69,
          "type": "multiple-choice",
          "prompt": "When firms lay off employees, they are:",
          "options": {
            "A": "treating employees as an intangible resource.",
            "B": "recognizing the reduced value of labor in the value chain.",
            "C": "eroding the organization's knowledge resources.",
            "D": "temporarily sacrificing a tangible asset that is easily replaced."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q70",
          "sourceNumber": 70,
          "type": "multiple-choice",
          "prompt": "Because firms combine tangible and intangible resources to create capabilities:",
          "options": {
            "A": "these capabilities are fragile and subject to sudden loss of value.",
            "B": "capabilities are often based on developing, carrying, and exchanging information and knowledge through the firm's human capital.",
            "C": "capabilities are easily transferred from one firm to another as employees change jobs.",
            "D": "these types of capabilities are considered primary activities in the value chain."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q71",
          "sourceNumber": 71,
          "type": "multiple-choice",
          "prompt": "______ can be viewed as the capacity to take action.",
          "options": {
            "A": "Strategic assets",
            "B": "Human capital",
            "C": "Core competencies",
            "D": "Functional capabilities"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q72",
          "sourceNumber": 72,
          "type": "multiple-choice",
          "prompt": "______ is an example of a capability that is based in the functional area of distribution.",
          "options": {
            "A": "Effective use of logistics management techniques",
            "B": "Effective control of inventories through point-of-purchase data collection",
            "C": "Effective organizational structure",
            "D": "Product and design quality"
          },
          "answer": "A"
        },
        {
          "id": "ch3-q73",
          "sourceNumber": 73,
          "type": "multiple-choice",
          "prompt": "Capabilities:",
          "options": {
            "A": "tend to be developed through firm-wide interactions and reside in the firm as a whole.",
            "B": "tend to be concentrated in the support activities of the value chain.",
            "C": "tend to be concentrated in the primary activities of the value chain.",
            "D": "are often developed in specific functional areas."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q74",
          "sourceNumber": 74,
          "type": "multiple-choice",
          "prompt": "Innovation, consumer understanding, brand-building, go-to-market, and scale are activities that P&G performs well and are examples of the company's:",
          "options": {
            "A": "tangible resources.",
            "B": "intangible resources.",
            "C": "core competencies.",
            "D": "capabilities."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q75",
          "sourceNumber": 75,
          "type": "multiple-choice",
          "prompt": "To provide a sustainable competitive advantage, a capability must satisfy all of the following criteria EXCEPT:",
          "options": {
            "A": "be technologically innovative.",
            "B": "be hard for competing firms to duplicate.",
            "C": "be without good substitutes.",
            "D": "be valuable to customers."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q76",
          "sourceNumber": 76,
          "type": "multiple-choice",
          "prompt": "From a customer's point of view, for an organization's capability to be a core competence it must be:",
          "options": {
            "A": "inimitable and unique.",
            "B": "valuable and unique.",
            "C": "inimitable and nonsubstitutable.",
            "D": "valuable and nonsubstitutable."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q77",
          "sourceNumber": 77,
          "type": "multiple-choice",
          "prompt": "Valuable capabilities:",
          "options": {
            "A": "allow the firm to exploit opportunities in its external environment.",
            "B": "allow the firm to neutralize threats in its internal environment.",
            "C": "allow the firm to exploit opportunities or neutralize threats in its external environment.",
            "D": "allow the firm to neutralize opportunities in its internal environment."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q78",
          "sourceNumber": 78,
          "type": "multiple-choice",
          "prompt": "Capabilities that other firms cannot develop easily are classified as:",
          "options": {
            "A": "costly to imitate.",
            "B": "rare.",
            "C": "valuable.",
            "D": "nonsubstitutable."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q79",
          "sourceNumber": 79,
          "type": "multiple-choice",
          "prompt": "A major department store chain has a strict policy of banning photographs or videos of its sales floor or back-room operations. It also does not allow academics to conduct studies of it for publication in research journals. In fact, some of its own top managers refer to the management's policies on secrecy as \"verging on paranoid.\" These policies indicate that the top management of the firm believes the organization's core competencies are:",
          "options": {
            "A": "causally ambiguous.",
            "B": "unobservable.",
            "C": "imitable.",
            "D": "common."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q80",
          "sourceNumber": 80,
          "type": "multiple-choice",
          "prompt": "Several months ago, a restaurant developed a new appetizer that is a hit with customers. Many customers go to the restaurant just for the appetizer, and it was at the center of a recent highly positive review by a food critic. Preparation involves common ingredients and average culinary skills but requires a very high oven temperature, which significantly increases utility costs. Several competing restaurants have since added their own version of the appetizer to their menu. Which criterion for assessing capabilities/core competencies is met?",
          "options": {
            "A": "The restaurant has the capability to develop something that is valuable.",
            "B": "The restaurant has the capability to develop something that is rare.",
            "C": "The restaurant has the capability to develop something that is costly to imitate.",
            "D": "All of these criteria are met."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q81",
          "sourceNumber": 81,
          "type": "multiple-choice",
          "prompt": "In the airline industry, frequent-flyer programs, ticket kiosks, and e-ticketing are all examples of capabilities that are ______ but no longer _____.",
          "options": {
            "A": "rare; valuable",
            "B": "valuable; rare",
            "C": "socially complex; rare",
            "D": "valuable; causally ambiguous"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q82",
          "sourceNumber": 82,
          "type": "multiple-choice",
          "prompt": "The capabilities used to create the sustainability/green initiatives at Walmart and Target are ______ but less likely to be ______.",
          "options": {
            "A": "rare; valuable",
            "B": "valuable; rare",
            "C": "socially complex; rare",
            "D": "valuable; causally ambiguous"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q83",
          "sourceNumber": 83,
          "type": "multiple-choice",
          "prompt": "Costly-to-imitate capabilities can emerge for all of the following reasons EXCEPT:",
          "options": {
            "A": "lack of scientific transference.",
            "B": "social complexity.",
            "C": "unique historical conditions.",
            "D": "causal ambiguity."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q84",
          "sourceNumber": 84,
          "type": "multiple-choice",
          "prompt": "A financial management firm has existed for more than 70 years. Some of its original clients' grandchildren are now clients of the firm themselves. The partners and staff of the firm have spent most or all of their careers with the firm. Many have even married into each other's families. This firm has capabilities that would be costly to imitate because of its",
          "options": {
            "A": "access to large amounts of financial capital.",
            "B": "causally ambiguous core competencies.",
            "C": "social complexity.",
            "D": "unique historical conditions."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q85",
          "sourceNumber": 85,
          "type": "multiple-choice",
          "prompt": "Southwest Airlines has a complex interrelationship between its culture and staff that adds value in ways that other airlines cannot, such as jokes on flights or the cooperation between gate personnel and pilots. These examples illustrate which of the following criteria for sustainable competitive advantage?",
          "options": {
            "A": "Valuable",
            "B": "Rare",
            "C": "Costly to imitate",
            "D": "Nonsubstitutable"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q86",
          "sourceNumber": 86,
          "type": "multiple-choice",
          "prompt": "McDonald's culture, with an emphasis on cleanliness, consistency, service, and the training that reinforces the value of these characteristics, illustrates which of the following criteria for sustainable competitive advantage?",
          "options": {
            "A": "Valuable",
            "B": "Rare",
            "C": "Costly to imitate",
            "D": "Nonsubstitutable"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q87",
          "sourceNumber": 87,
          "type": "multiple-choice",
          "prompt": "Organizational culture is:",
          "options": {
            "A": "amorphous and changeable.",
            "B": "not easily imitable.",
            "C": "so difficult to analyze that most firms should choose to ignore it.",
            "D": "typically fragile in the face of changes in the external environment."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q88",
          "sourceNumber": 88,
          "type": "multiple-choice",
          "prompt": "Gamma, Inc., has struggled for industry dominance with Ardent, Inc., its main competitor, for years. Gamma has gathered and analyzed large amounts of competitive intelligence about Ardent. It has observed as much of the firm's internal functioning and technology as it can legally, yet Gamma cannot understand why Ardent has a competitive advantage over it. The source of Ardent's success is",
          "options": {
            "A": "impregnable.",
            "B": "causally ambiguous.",
            "C": "rationally obscure.",
            "D": "elusive."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q89",
          "sourceNumber": 89,
          "type": "multiple-choice",
          "prompt": "If a firm offers a service that is valuable, rare, and costly to imitate, but a substitute exists for the service, the firm will:",
          "options": {
            "A": "achieve competitive parity.",
            "B": "have a competitive disadvantage.",
            "C": "have a temporary competitive advantage.",
            "D": "gain a sustainable competitive advantage."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q90",
          "sourceNumber": 90,
          "type": "multiple-choice",
          "prompt": "ACME Corp. is a leading provider of radios to the commercial market. Its products all rely on printed circuit-board technology. ACME has protected its market leadership with continued advancements in this technology, which it patents. A competitor has developed a radio for this market with equal performance but uses a software-based technology instead of circuit boards. ACME's technology leadership fails which capability test?",
          "options": {
            "A": "The value test",
            "B": "The rareness test",
            "C": "The substitutability test",
            "D": "The costly-to-imitate test"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q91",
          "sourceNumber": 91,
          "type": "multiple-choice",
          "prompt": "Firms that achieve competitive parity can expect to:",
          "options": {
            "A": "earn below-average returns.",
            "B": "earn average returns.",
            "C": "earn above-average returns.",
            "D": "initially earn above-average returns, declining to average returns."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q92",
          "sourceNumber": 92,
          "type": "multiple-choice",
          "prompt": "A veterinary practice has added a pet boarding and grooming facility. Most of the practice's competitors also provide these services. The veterinary practice is gaining competitive:",
          "options": {
            "A": "advantage.",
            "B": "parity.",
            "C": "disadvantage.",
            "D": "neutrality."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q93",
          "sourceNumber": 93,
          "type": "multiple-choice",
          "prompt": "A local restaurant, Farm Fresh Ingredients, has become highly successful through its menu, based solely on organically raised chicken and beef, and organic seasonal produce. It has opened new locations in other cities, and these new locations are becoming highly profitable. Farm Fresh can expect that, at best, its competitive advantage will be:",
          "options": {
            "A": "permanent.",
            "B": "sustainable.",
            "C": "temporary.",
            "D": "defensible."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q94",
          "sourceNumber": 94,
          "type": "multiple-choice",
          "prompt": "Value chain activities are:",
          "options": {
            "A": "the activities most likely to be imitated by competitors.",
            "B": "activities or tasks the firm completes in order to produce products and then sell, distribute, and service those products in ways that create value for customers.",
            "C": "the core competencies of the organization.",
            "D": "the activities most crucial to implementing the firm's business strategy."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q95",
          "sourceNumber": 95,
          "type": "multiple-choice",
          "prompt": "Value chain activities include all of the following EXCEPT:",
          "options": {
            "A": "supply-chain management.",
            "B": "operations.",
            "C": "management information systems.",
            "D": "distribution."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q96",
          "sourceNumber": 96,
          "type": "multiple-choice",
          "prompt": "Examples of support activities include all of the following EXCEPT:",
          "options": {
            "A": "finance.",
            "B": "human resources.",
            "C": "follow-up service.",
            "D": "management information systems."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q97",
          "sourceNumber": 97,
          "type": "multiple-choice",
          "prompt": "Value chain analysis is a tool used to:",
          "options": {
            "A": "analyze a firm's external environment for value-creating opportunities.",
            "B": "analyze a firm's value chain activities and support functions in isolation from its competitors' value chain.",
            "C": "understand the parts of the firm's operation that create value and those that do not.",
            "D": "identify the firm's core competencies in each of the primary activities of the firm."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q98",
          "sourceNumber": 98,
          "type": "multiple-choice",
          "prompt": "Firms that have strong positive relationships with suppliers and customers are said to have ______, an essential ingredient to creating value.",
          "options": {
            "A": "customer value",
            "B": "social capital",
            "C": "effective marketing",
            "D": "an attractive industry"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q99",
          "sourceNumber": 99,
          "type": "multiple-choice",
          "prompt": "Knowledge transfer and access to resources within the value chain are enhanced by:",
          "options": {
            "A": "guidelines for sharing knowledge and resources.",
            "B": "social capital.",
            "C": "penalties for not sharing knowledge and resources.",
            "D": "training employees on how to cooperate."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q100",
          "sourceNumber": 100,
          "type": "multiple-choice",
          "prompt": "To build social capital whereby resources such as knowledge are transferred across organizations requires ______ between the parties.",
          "options": {
            "A": "a contract",
            "B": "determination",
            "C": "confidence",
            "D": "trust"
          },
          "answer": "D"
        },
        {
          "id": "ch3-q101",
          "sourceNumber": 101,
          "type": "multiple-choice",
          "prompt": "Outsourcing is the:",
          "options": {
            "A": "spinning off of a value-creating activity to create a new firm.",
            "B": "selling of a value-creating activity to other firms.",
            "C": "purchase of a value-creating activity from an external supplier.",
            "D": "use of computers to obtain value-creating data from the Internet."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q102",
          "sourceNumber": 102,
          "type": "multiple-choice",
          "prompt": "A major reason outsourcing is effective is that:",
          "options": {
            "A": "it increases the innovative potential of the firm.",
            "B": "few firms possess superior capability in all primary and support activities.",
            "C": "it permits unlimited access to capital resources.",
            "D": "competitors do not have access to the same external sources."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q103",
          "sourceNumber": 103,
          "type": "multiple-choice",
          "prompt": "Which of the following is TRUE about outsourcing?",
          "options": {
            "A": "Outsourcing allows firms to be more flexible and requires minimal coordination.",
            "B": "Outsourcing allows firms to concentrate on those areas in which they can create value.",
            "C": "Outsourcing strengthens the creative and innovative functions within the firm.",
            "D": "Outsourcing is effective only when it includes all support activities."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q104",
          "sourceNumber": 104,
          "type": "multiple-choice",
          "prompt": "A major U.S. manufacturer of children's toys believes its main competitive advantage lies in its continuing development of innovative toys and games. The company is facing increasing competition on price, and it is strongly considering outsourcing to offshore firms as a means of reducing costs. The LAST function this firm should consider outsourcing is:",
          "options": {
            "A": "operations.",
            "B": "research and development.",
            "C": "supply-chain management.",
            "D": "distribution."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q105",
          "sourceNumber": 105,
          "type": "multiple-choice",
          "prompt": "The owner of a store that sells fine-quality fabrics for home seamstresses bemoans the fact that few young women know how to do fine tailoring, much less simple dressmaking. Many potential customers are unable to appreciate the premium quality of the fabrics and are deterred by the high prices, as well as the complexity of fine sewing. In the past, the store had a strong demand for fabrics, large classes for women learning the fine points of sewing, and a reputation for excellent service and technical advice. Now the store is earning lower-than-average returns. This case is an example of:",
          "options": {
            "A": "the hazard of competitors being able to imitate a firm's core competency.",
            "B": "the need for firms to stick to their core competencies through temporary downturns in market demand.",
            "C": "the lack of intangible resources undermining the core competencies of the firm.",
            "D": "core competencies that have become core rigidities."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q106",
          "sourceNumber": 106,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT an external event that reveals the \"dark side\" of core capabilities?",
          "options": {
            "A": "A new competitor figures out a better way to serve the firm's customers.",
            "B": "New technologies emerge and replace those used by the firm.",
            "C": "A firm changes its focus to a new core competence.",
            "D": "Political or social events shift the foundation of current core capabilities."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q107",
          "sourceNumber": 107,
          "type": "multiple-choice",
          "prompt": "Acme Auto Repair has a thriving business based on its reputation for high-quality work, honesty, and skilled employees. For continued long-term success, Acme's owner should:",
          "options": {
            "A": "concentrate on maintaining Acme's current core competencies.",
            "B": "focus on developing Acme's future competitive advantages.",
            "C": "place more emphasis on tangible resources, which are less vulnerable to obsolescence than intangible resources.",
            "D": "recognize that core competencies derived from human resources are more subject to becoming core rigidities than are core competencies based on other types of resources."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q108",
          "sourceNumber": 108,
          "type": "multiple-choice",
          "prompt": "All of the following were traditional sources of competitive advantage EXCEPT:",
          "options": {
            "A": "labor costs.",
            "B": "access to financial resources.",
            "C": "protected markets.",
            "D": "a highly educated labor market."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q109",
          "sourceNumber": 109,
          "type": "multiple-choice",
          "prompt": "______ is the ability to analyze, understand, and manage an internal organization in ways that are not dependent on the assumptions of a single country, culture, or context.",
          "options": {
            "A": "Strategic thinking",
            "B": "A global mind-set",
            "C": "Profit-pooling",
            "D": "Competency-discovering"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q110",
          "sourceNumber": 110,
          "type": "multiple-choice",
          "prompt": "A product's value is created by each of the following EXCEPT:",
          "options": {
            "A": "high cost and highly differentiated features.",
            "B": "low cost.",
            "C": "highly differentiated features.",
            "D": "low cost and highly differentiated features."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q111",
          "sourceNumber": 111,
          "type": "multiple-choice",
          "prompt": "A firm's core competencies, integrated with an understanding of the results of studying the conditions in the external environment, should:",
          "options": {
            "A": "guarantee profits.",
            "B": "lead to a first-mover advantage.",
            "C": "drive the selection of strategies.",
            "D": "increase the firm's market share."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q112",
          "sourceNumber": 112,
          "type": "multiple-choice",
          "prompt": "All of the following are true about the strategic decisions managers make about their firm's internal organization EXCEPT that:",
          "options": {
            "A": "they are directly correlated to executive compensation.",
            "B": "they are non-routine.",
            "C": "they have ethical implications.",
            "D": "they significantly influence the firm's ability to earn above-average returns."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q113",
          "sourceNumber": 113,
          "type": "multiple-choice",
          "prompt": "One capability that can be learned from failure is when to:",
          "options": {
            "A": "repeat with a modification.",
            "B": "add more resources.",
            "C": "dig in.",
            "D": "quit."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q114",
          "sourceNumber": 114,
          "type": "multiple-choice",
          "prompt": "Subscriptions to the New York Times have been decreasing as more customers receive their news through other media. At the same time, advertisers have shifted portions of their spending to other media. The NYT's managers are making decisions under:",
          "options": {
            "A": "certainty.",
            "B": "uncertainty.",
            "C": "intraorganizational conflict.",
            "D": "interorganizational conflict."
          },
          "answer": "B"
        },
        {
          "id": "ch3-q115",
          "sourceNumber": 115,
          "type": "multiple-choice",
          "prompt": "Amazon is building a new distribution facility in Robbinsville, New Jersey. It is immediately off the exit of a major road. This is an example of a(n) ______ resource.",
          "options": {
            "A": "financial",
            "B": "organizational",
            "C": "physical",
            "D": "technological"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q116",
          "sourceNumber": 116,
          "type": "multiple-choice",
          "prompt": "The corporate research division of Siemens files, on average, 25 patents a day. The patents are a(n) ______ resource.",
          "options": {
            "A": "financial",
            "B": "organizational",
            "C": "physical",
            "D": "technological"
          },
          "answer": "D"
        },
        {
          "id": "ch3-q117",
          "sourceNumber": 117,
          "type": "multiple-choice",
          "prompt": "Government agencies are known for having so many layers and rules that decisions are made slowly and inefficiently. In this case the ______ resource is a detriment to taxpayers using and paying for the bureaucracy.",
          "options": {
            "A": "financial",
            "B": "organizational",
            "C": "physical",
            "D": "technological"
          },
          "answer": "B"
        },
        {
          "id": "ch3-q118",
          "sourceNumber": 118,
          "type": "multiple-choice",
          "prompt": "A food bank in Florida was struggling to serve its customers. It asked Walmart for help. Walmart sent a team of managers who reorganized storage and transportation. The food bank was able to increase the number of clients served by tenfold. Walmart shared its expertise in:",
          "options": {
            "A": "distribution.",
            "B": "human resources.",
            "C": "marketing.",
            "D": "manufacturing."
          },
          "answer": "A"
        },
        {
          "id": "ch3-q119",
          "sourceNumber": 119,
          "type": "multiple-choice",
          "prompt": "Charmed by Claire is a successful retail boutique that sells women's accessories. Claire, the owner/manager, knows that women have many options when buying jewelry. When customers enter her store they are greeted by name and given prompt, friendly attention. Customers return to the store because the service is excellent. Claire says the most important decision she makes is hiring the best staff because customer service is vital to her business. Customer service is:",
          "options": {
            "A": "a human resource.",
            "B": "an organizational resource.",
            "C": "a rare resource.",
            "D": "a core competency."
          },
          "answer": "D"
        },
        {
          "id": "ch3-q120",
          "sourceNumber": 120,
          "type": "multiple-choice",
          "prompt": "Many firms outsource the payroll function of paying employees to firms such as ADP. Payroll is a(n):",
          "options": {
            "A": "value-chain activity.",
            "B": "operation function.",
            "C": "support function.",
            "D": "supply-chain function."
          },
          "answer": "C"
        },
        {
          "id": "ch3-q121",
          "sourceNumber": 121,
          "type": "multiple-choice",
          "prompt": "The ______ are those with the potential to be formed into core competencies as the foundation for creating value.",
          "options": {
            "A": "\"most\" knowledge resources",
            "B": "\"most\" capabilities",
            "C": "\"right\" resources",
            "D": "\"dark side\" resources"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q122",
          "sourceNumber": 122,
          "type": "multiple-choice",
          "prompt": "Tools such as ______ help the firm focus on its core competencies as the source of its competitive advantages.",
          "options": {
            "A": "marketing",
            "B": "manufacturing",
            "C": "outsourcing",
            "D": "imitation"
          },
          "answer": "C"
        },
        {
          "id": "ch3-q123",
          "sourceNumber": 123,
          "type": "multiple-choice",
          "prompt": "All core competencies have the potential to become core:",
          "options": {
            "A": "rigidities.",
            "B": "stagnations.",
            "C": "inefficiencies.",
            "D": "weaknesses."
          },
          "answer": "A"
        }
      ]
    },
    {
      "number": 4,
      "title": "Chapter 4 Business-Level Strategy",
      "questions": [
        {
          "id": "ch4-q38",
          "sourceNumber": 38,
          "type": "multiple-choice",
          "prompt": "Business-level strategies detail commitments and actions taken to provide value to customers and gain competitive advantage by exploiting core competencies in:",
          "options": {
            "A": "the selection of industries in which the firm will compete.",
            "B": "specific product markets.",
            "C": "primary value chain activities.",
            "D": "particular geographic locations."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q39",
          "sourceNumber": 39,
          "type": "multiple-choice",
          "prompt": "A firm's core strategy is its ____ strategy.",
          "options": {
            "A": "corporate",
            "B": "business",
            "C": "pricing",
            "D": "international"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q40",
          "sourceNumber": 40,
          "type": "multiple-choice",
          "prompt": "When selecting a business level strategy, the firm must determine all of the following EXCEPT:",
          "options": {
            "A": "how will the customer's needs be satisfied?",
            "B": "who is the customer?",
            "C": "what are the customers' needs?",
            "D": "why should these customers' needs be satisfied?"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q41",
          "sourceNumber": 41,
          "type": "multiple-choice",
          "prompt": "The three dimensions of a firm's relationships with customers include all the following EXCEPT:",
          "options": {
            "A": "exclusiveness.",
            "B": "affiliation.",
            "C": "richness.",
            "D": "reach."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q42",
          "sourceNumber": 42,
          "type": "multiple-choice",
          "prompt": "Which of the following is TRUE?",
          "options": {
            "A": "As customer loyalty increases, customers are more sensitive to price increases.",
            "B": "Customer loyalty has a positive relationship with firm profitability.",
            "C": "Customer loyalty is fragile and cannot reliably be considered a factor in firm success.",
            "D": "Customer loyalty is of importance only to firms using the differentiation strategy."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q43",
          "sourceNumber": 43,
          "type": "multiple-choice",
          "prompt": "The ________dimension of relationships with customers is particularly important for social networking sites such as Facebook and Twitter.",
          "options": {
            "A": "reach",
            "B": "richness",
            "C": "affiliation",
            "D": "social"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q44",
          "sourceNumber": 44,
          "type": "multiple-choice",
          "prompt": "Amazon has built capabilities around Internet technology and e-commerce to facilitate information exchanges with its customers in a cost effective manner. This represents which of the three service dimension?",
          "options": {
            "A": "Reach",
            "B": "Richness",
            "C": "Affiliation",
            "D": "None of the these options are correct."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q45",
          "sourceNumber": 45,
          "type": "multiple-choice",
          "prompt": "Viewing the world through the customer's eyes and constantly seeking ways to create more value for the company enhances:",
          "options": {
            "A": "the reach of the company toward the customer.",
            "B": "the ability to identify the customer.",
            "C": "the richness of the relationship with the customer.",
            "D": "affiliation with the customer."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q46",
          "sourceNumber": 46,
          "type": "multiple-choice",
          "prompt": "Before the firm decides what products to offer and what benefits and features they will have, the firm must decide all the following questions EXCEPT:",
          "options": {
            "A": "who the firm should serve.",
            "B": "when the customer's needs should be satisfied.",
            "C": "what needs the firm should satisfy.",
            "D": "what core competencies are needed to satisfy customer needs."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q47",
          "sourceNumber": 47,
          "type": "multiple-choice",
          "prompt": "In the animal food products business, food-product needs of owners of companion animals pets (e.g., dogs and cats) differ from the needs for food and health-related products of those owning production animals (e.g., livestock). Which of the following aspects of managing customer relationships does this choice refer to?",
          "options": {
            "A": "Who: Determining the Customers to Serve",
            "B": "What: Determining Which Customer Needs to Satisfy",
            "C": "How: Determining Core Competencies Necessary to satisfy Customer Needs",
            "D": "When: Determining When to Satisfy Customer Needs"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q48",
          "sourceNumber": 48,
          "type": "multiple-choice",
          "prompt": "Starbuck's determined that all of the following customer needs were important EXCEPT:",
          "options": {
            "A": "low price.",
            "B": "the experience associated with drinking coffee, not just the coffee.",
            "C": "the actual product of service (e.g., a cup of coffee), not the experience.",
            "D": "allowing customer to design their own drinks."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q49",
          "sourceNumber": 49,
          "type": "multiple-choice",
          "prompt": "Hyundai allows customers to return their cars if they lose their job within 12 months of purchase. Which of the following aspects of managing customer relationships is Hyundai engaged in?",
          "options": {
            "A": "Who: Determining the Customers to Serve",
            "B": "What: Determining Which Customer Needs to Satisfy",
            "C": "How: Determining Core Competencies Necessary to satisfy Customer Needs",
            "D": "When: Determining When to Satisfy Customer Needs"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q50",
          "sourceNumber": 50,
          "type": "multiple-choice",
          "prompt": "An interior decorator has moved his business from Los Angeles to St. Paul, Minnesota, because his spouse's company transferred her to St. Paul. The decorator is distressed because the customers in his target market have, in his words, \"banal and bourgeois taste.\" What is the decorator's problem?",
          "options": {
            "A": "The decorator does not understand that customer needs are neither right nor wrong, good nor bad.",
            "B": "The decorator has no core competencies that will transfer to his new geographic market.",
            "C": "The decorator should choose a strategy of cost leadership in this environment.",
            "D": "The decorator is highly affiliated with the new target market and understands how he can create value for it."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q51",
          "sourceNumber": 51,
          "type": "multiple-choice",
          "prompt": "In order to meet and exceed customer's expectations, firms must:",
          "options": {
            "A": "constantly manipulate customers' perceptions of their needs.",
            "B": "answer the questions: who, what, when, where, how, and why as they apply to customers.",
            "C": "continuously improve, innovate, and upgrade their core competencies.",
            "D": "successfully defend their established core competencies from imitation by competitors."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q52",
          "sourceNumber": 52,
          "type": "multiple-choice",
          "prompt": "Business-level strategies are concerned specifically with:",
          "options": {
            "A": "creating differences between the firm's position and its competitors.",
            "B": "selecting the industries in which the firm will compete.",
            "C": "how functional areas will be organized within the firm.",
            "D": "how a business with multiple physical locations will operate one of those locations."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q53",
          "sourceNumber": 53,
          "type": "multiple-choice",
          "prompt": "An entrepreneur is investigating starting a company that provides tax advice to small companies. In order to position his company differently from the existing competitors, the entrepreneur must:",
          "options": {
            "A": "analyze the reach, richness, and affiliation the company must have with its customers.",
            "B": "provide tax advice either in a different manner or provide a different kind of tax service than competitors.",
            "C": "offer tax advice at a price lower than the cheapest competitor.",
            "D": "offer tax advice at a higher quality than the best competitor."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q54",
          "sourceNumber": 54,
          "type": "multiple-choice",
          "prompt": "Which of the following are central to implementing value-creating strategies and thereby satisfying customers' needs?",
          "options": {
            "A": "Firm resources",
            "B": "Capabilities",
            "C": "Core competencies",
            "D": "None of the the above"
          },
          "answer": "C"
        },
        {
          "id": "ch4-q55",
          "sourceNumber": 55,
          "type": "multiple-choice",
          "prompt": "The analysis of the activity map of a successful company such as Southwest Airlines emphasizes how:",
          "options": {
            "A": "the organizational culture of Southwest Airlines is the key to the success of the organization.",
            "B": "understanding the profit ability in an industry indicates to companies where above-average returns can be earned.",
            "C": "it is hard for rivals to match a configuration of integrated activities than to imitate a single activity.",
            "D": "the primary and support activities of a successful company capture value all along the value chain."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q56",
          "sourceNumber": 56,
          "type": "multiple-choice",
          "prompt": "By examining the ____ of Southwest Airlines, one can identify the strategic themes around which it has developed its business strategy. These themes include limited passenger service, high aircraft utilization, and highly productive ground and gate crews.",
          "options": {
            "A": "activity map",
            "B": "profit sharing",
            "C": "value diagram",
            "D": "five forces model"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q57",
          "sourceNumber": 57,
          "type": "multiple-choice",
          "prompt": "If Southwest Airlines employees lost their high enthusiasm and commitment to the company:",
          "options": {
            "A": "the airline could continue without problems because its cost leadership strategy is dependent on its efficient internal procedures.",
            "B": "replacement employees could be hired from rival airlines that are laying off employees and easily be merged into the Southwest culture.",
            "C": "there would be no impact on Southwest's profitability because Southwest's customers value the low fares rather than being \"entertained\" by the employees.",
            "D": "Southwest would have lost one of its competitive advantages, and its performance would be threatened."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q58",
          "sourceNumber": 58,
          "type": "multiple-choice",
          "prompt": "Strategic fit among many activities (in an activity map) is fundamental to:",
          "options": {
            "A": "the development of core competencies for a firm.",
            "B": "the breadth of competitive scope for a firm.",
            "C": "sustainability of a firm's competitive advantage.",
            "D": "the integrity of the firm's value chain."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q59",
          "sourceNumber": 59,
          "type": "multiple-choice",
          "prompt": "All of the following are considered generic business-level strategies EXCEPT:",
          "options": {
            "A": "product diversification.",
            "B": "cost leadership.",
            "C": "focused differentiation.",
            "D": "integrated cost leadership/differentiation."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q60",
          "sourceNumber": 60,
          "type": "multiple-choice",
          "prompt": "A company using a narrow target market in its business strategy is:",
          "options": {
            "A": "following a cost leadership business strategy.",
            "B": "focusing on a broad array of geographic markets.",
            "C": "limiting the group of customer segments served.",
            "D": "decreasing the number of activities on its value chain."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q61",
          "sourceNumber": 61,
          "type": "multiple-choice",
          "prompt": "As the television industry has changed in the last few decades from just three major networks to a multiplicity of networks, one of the major aspects of business strategy for the newer networks is ____ than the traditional networks.",
          "options": {
            "A": "broader target market",
            "B": "narrower target market",
            "C": "increased use of primary activities to capture value",
            "D": "increased use of support activities to capture value"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q62",
          "sourceNumber": 62,
          "type": "multiple-choice",
          "prompt": "The effectiveness of any of the generic business-level strategies is contingent upon:",
          "options": {
            "A": "customer needs and competitors' strategies.",
            "B": "the match between the opportunities and threats in its external market and the strengths of its internal environment.",
            "C": "the trends in the general consumer base and the robustness of the global and industry economy.",
            "D": "the firm's competitive scope and its competitive advantage."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q63",
          "sourceNumber": 63,
          "type": "multiple-choice",
          "prompt": "A cost leadership strategy provides goods or services with features that are:",
          "options": {
            "A": "acceptable.",
            "B": "unique.",
            "C": "substandard.",
            "D": "mediocre."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q64",
          "sourceNumber": 64,
          "type": "multiple-choice",
          "prompt": "A cost leadership strategy targets the industry's ____ customers.",
          "options": {
            "A": "most typical",
            "B": "poorest",
            "C": "least educated",
            "D": "most frugal"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q65",
          "sourceNumber": 65,
          "type": "multiple-choice",
          "prompt": "Durable Ceramics, Inc., provides inexpensive ceramic tile to builders of institutional buildings such as schools, prisons, and public administration buildings. It has always competed on a cost leadership basis. Most of its products are purchased by a few commercial construction firms, so it is fairly dependent on these construction firms for selling its product. Durable Ceramic's next most-efficient competitor, Cost-Less Ceramics, Inc., earns average returns, whereas Durable earns above-average returns. The commercial construction firms are putting pressure on Durable to reduce its prices. If Durable reduces its prices below those of Cost-Less's prices, it is likely that:",
          "options": {
            "A": "both Durable and Cost-Less will devise additional ways to become more efficient in their production processes.",
            "B": "Durable will be unable to absorb the lower cost, and will go out of business.",
            "C": "both Cost-Less and Durable will go out of business, leaving the customers with fewer alternative sources of low-cost tile.",
            "D": "Cost-Less will go out of business, and Durable will gain higher power over its customers."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q66",
          "sourceNumber": 66,
          "type": "multiple-choice",
          "prompt": "Research suggests that having a competitive advantage in ____ creates more value in the cost leadership strategy than it does in the differentiation strategy.",
          "options": {
            "A": "marketing and sales",
            "B": "technology development",
            "C": "logistics",
            "D": "human resource management"
          },
          "answer": "C"
        },
        {
          "id": "ch4-q67",
          "sourceNumber": 67,
          "type": "multiple-choice",
          "prompt": "A river barge company can offer cheaper, although slower, per pound transportation of products to companies when compared with transportation by air, truck, or rail. The river barge company should first target customers whose companies use:",
          "options": {
            "A": "the integrated cost leadership/differentiation strategy.",
            "B": "either of the focus strategies.",
            "C": "the cost leadership strategy.",
            "D": "any of the strategies except the focused differentiation strategy."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q68",
          "sourceNumber": 68,
          "type": "multiple-choice",
          "prompt": "Walmart went against business-level strategy and made changes to attract upscale customers. These changes had which of the following results?",
          "options": {
            "A": "It strengthened Walmart's position against rivals such as Dollar Stores and Amazon.",
            "B": "It made Walmart vulnerable to Dollar Store and Amazon.",
            "C": "It attracted significant numbers of new customers.",
            "D": "Family Dollar, Dollar Tree, and Dollar General all experienced losses in sales as many of their customers went to Walmart."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q69",
          "sourceNumber": 69,
          "type": "multiple-choice",
          "prompt": "Walmart's same store sales have been declining and those of rivals Family Dollar and Amazon have been increasing. What could explain this recent change?",
          "options": {
            "A": "Walmart was too aggressive with its low-cost position and lost customers who wanted more upscale products.",
            "B": "Walmart changed its strategy to focused differentiation.",
            "C": "Amazon and Family Dollar changed their strategies to attract more upscale customers.",
            "D": "Walmart changed its strategy to attract more upscale customers."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q70",
          "sourceNumber": 70,
          "type": "multiple-choice",
          "prompt": "A company pursuing the differentiation or focused differentiation strategy would tend to:",
          "options": {
            "A": "build economies of scale and efficient operations.",
            "B": "develop and maintain cost-effective MIS operations.",
            "C": "develop flexible systems that allow rapid response to customers' changing needs.",
            "D": "have relationships with suppliers to maintain efficient flow of supplies for operations."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q71",
          "sourceNumber": 71,
          "type": "multiple-choice",
          "prompt": "When the costs of supplies increase in an industry, the low-cost leader:",
          "options": {
            "A": "may continue competing with rivals on the basis of product features.",
            "B": "will lose customers as a result of price increases.",
            "C": "will be unable to absorb higher costs because cost-leaders operate on very narrow profit margins.",
            "D": "may be the only firm able to pay the higher prices and continue to earn average or above-average returns."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q72",
          "sourceNumber": 72,
          "type": "multiple-choice",
          "prompt": "Ever-improving levels of efficiency enhance profit margins for a cost-leader. This effects which of the five forces of industry structure most directly?",
          "options": {
            "A": "Potential entrants",
            "B": "Substitutes",
            "C": "Buyer power",
            "D": "Supplier power"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q73",
          "sourceNumber": 73,
          "type": "multiple-choice",
          "prompt": "The typical risks of a cost leadership strategy include:",
          "options": {
            "A": "the inability to balance high differentiation and low price.",
            "B": "production and distribution processes becoming obsolete.",
            "C": "excessive differentiation to the point where the customer base is too small.",
            "D": "loss of customer loyalty."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q74",
          "sourceNumber": 74,
          "type": "multiple-choice",
          "prompt": "When a firm is able to produce nonstandardized (that is, distinctive) products for customers who value differentiated features more than they value low cost, the firm is successfully implementing:",
          "options": {
            "A": "a differentiation strategy.",
            "B": "a cost leadership strategy.",
            "C": "an integrated cost leadership/differentiation strategy.",
            "D": "a single-product strategy."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q75",
          "sourceNumber": 75,
          "type": "multiple-choice",
          "prompt": "A firm successfully implementing a differentiation strategy would expect:",
          "options": {
            "A": "customers to be sensitive to price increases.",
            "B": "to charge premium prices.",
            "C": "customers to perceive the product as standard.",
            "D": "to have high levels of power over suppliers."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q76",
          "sourceNumber": 76,
          "type": "multiple-choice",
          "prompt": "The products or services that are differentiated from others, have qualities that are:",
          "options": {
            "A": "perceived by the customer to add value that they will pay a premium to purchase.",
            "B": "valued by the typical industry customer.",
            "C": "perceived as standardized by the customer.",
            "D": "seen as classic attributes rather than passing fads."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q77",
          "sourceNumber": 77,
          "type": "multiple-choice",
          "prompt": "Blind taste-tests have shown that the taste of premium-priced vodkas and inexpensive vodkas are indistinguishable even to regular drinkers of vodka. But the sales of premium vodkas are thriving. This is an example of:",
          "options": {
            "A": "the perception of perceived prestige and status as a means of differentiating a product.",
            "B": "the importance of high-quality raw materials when using the differentiation strategy.",
            "C": "the risk of product imitation by competitors.",
            "D": "the danger counterfeiting holds for firms pursuing the differentiation strategy."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q78",
          "sourceNumber": 78,
          "type": "multiple-choice",
          "prompt": "All of the following are examples of differentiated products EXCEPT:",
          "options": {
            "A": "Mont Blanc pens.",
            "B": "Caterpillar's heavy-duty earth-moving equipment.",
            "C": "Great Value brand at Walmart.",
            "D": "Prada fashion."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q79",
          "sourceNumber": 79,
          "type": "multiple-choice",
          "prompt": "The use of a differentiation strategy would be expected to be LEAST effective in which of the following markets?",
          "options": {
            "A": "Commodity goods",
            "B": "Mmotion pictures",
            "C": "Popular music",
            "D": "Writing instruments"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q80",
          "sourceNumber": 80,
          "type": "multiple-choice",
          "prompt": "All of the following are ways that a good or service can be differentiated EXCEPT:",
          "options": {
            "A": "responsive customer service.",
            "B": "perceived prestige and status.",
            "C": "economies of scale and efficient operations.",
            "D": "engineering design and performance."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q81",
          "sourceNumber": 81,
          "type": "multiple-choice",
          "prompt": "The differentiation strategy can be effective in controlling the power of rivalry with existing competitors in an industry because:",
          "options": {
            "A": "customers will seek out the lowest-cost product.",
            "B": "customers of nondifferentiated products are sensitive to price increases.",
            "C": "customers are loyal to brands that are differentiated in meaningful ways.",
            "D": "the differentiation strategy benefits from rivalry because it forces the firm to innovate."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q82",
          "sourceNumber": 82,
          "type": "multiple-choice",
          "prompt": "Wholesome Pet Food has successfully specialized for 20 years in high-quality pet food made from all-natural ingredients and organically raised lamb. This brand has a strong following and is recommended by veterinarians who practice in affluent neighborhoods. Wholesome's main supplier of lamb has announced that the price for lamb will be 15 percent higher next year. Which one of the following is true?",
          "options": {
            "A": "Wholesome will probably be able to pass the cost on to its customers because they are less sensitive to price increases than the average buyer.",
            "B": "Companies pursuing Wholesome's business strategy are especially vulnerable to this risk.",
            "C": "If Wholesome raises its pet food prices, customers will turn to less expensive brands such as Purina.",
            "D": "Wholesome probably operates on very thin margins, and a cost increase will threaten its ability to earn average returns."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q83",
          "sourceNumber": 83,
          "type": "multiple-choice",
          "prompt": "Which of the following is NOT a value-creating activity associated with the differentiation strategy?",
          "options": {
            "A": "Developing policies to ensure efficient hiring and retention to keep costs low and implement training to ensure high employee efficiency.",
            "B": "Providing accurate and timely delivery of goods to customers.",
            "C": "Ensuring receipt of high quality supplies (raw materials and other goods).",
            "D": "Developing flexible systems that allow rapid response to customers' changing needs."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q84",
          "sourceNumber": 84,
          "type": "multiple-choice",
          "prompt": "A differentiation strategy can be effective in controlling the power of substitutes in an industry because:",
          "options": {
            "A": "customers have low switching costs.",
            "B": "substitute products are lower quality.",
            "C": "a differentiating firm can always lower prices.",
            "D": "customers develop brand loyalty."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q85",
          "sourceNumber": 85,
          "type": "multiple-choice",
          "prompt": "Recently, the only type of car available for Anthony to rent on a business trip was a compact, fuel-efficient Japanese import. Anthony was surprised at the comfort and performance of the car. He is in the market for a new car and had previously considered only buying another luxury SUV. Now, he is thinking about the significant cost savings he would have if he bought the compact vehicle rather than a new SUV. This is an example of the competitive risk that:",
          "options": {
            "A": "a competitor's products can convey a product's differentiated features to a customer at a significantly reduced price.",
            "B": "a product imitation can cause customers to perceive that competitors offer essentially the same goods.",
            "C": "experience can narrow a customer's perceptions of the value of a product's differentiated features.",
            "D": "brand loyalty insulates a company from rivalry with competitors."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q86",
          "sourceNumber": 86,
          "type": "multiple-choice",
          "prompt": "A manufacturer of jewelry imitates the style of a popular and expensive brand using manufactured stones rather than real gemstones and lesser grade metals rather than silver and gold. The manufacturer packages the jewelry in boxes of the same color imprinted with an almost identical logo. About 85 percent of the company's sales are through Internet sales. This example illustrates the competitive risk of ____ that threatens companies that use the differentiation strategy.",
          "options": {
            "A": "customer sensitive to price differentials",
            "B": "threat by the cost leader",
            "C": "customer experience",
            "D": "counterfeiting"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q87",
          "sourceNumber": 87,
          "type": "multiple-choice",
          "prompt": "The typical risks of a differentiation strategy do NOT include which of the following?",
          "options": {
            "A": "Customers may find the price differential between the low-cost product and the differentiated product too large.",
            "B": "Customers' experience with other products may narrow customers' perception of the value of a product's differentiated features.",
            "C": "Counterfeit goods are widely available and acceptable to customers.",
            "D": "Suppliers of raw materials erode the firm's profit margin with price increases."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q88",
          "sourceNumber": 88,
          "type": "multiple-choice",
          "prompt": "When implementing a focus strategy, the firm seeks to:",
          "options": {
            "A": "offer products that are both differentiated and low cost.",
            "B": "move into the global market.",
            "C": "target the typical customer in an industry.",
            "D": "serve the specialized needs of a market segment."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q89",
          "sourceNumber": 89,
          "type": "multiple-choice",
          "prompt": "The focused differentiation strategy differs from the differentiation strategy in that:",
          "options": {
            "A": "the focused differentiators have a broader competitive scope.",
            "B": "the value-creating activities of focused differentiators are more constrained.",
            "C": "focused differentiators target a narrower customer market.",
            "D": "there are fewer risks with the focused differentiation strategy."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q90",
          "sourceNumber": 90,
          "type": "multiple-choice",
          "prompt": "Chico's is a clothing retailer that targets middle-aged women who want stylish and appealing clothes that are suitable for the mature figure. Chico's has an extensive customer list, a frequent-buyer discount card, and frequent sales promotions to Chico's customers based on their spending levels. Chico's uses a ____ strategy.",
          "options": {
            "A": "focused differentiation based on a buyer group",
            "B": "focused differentiation based on a product line segment",
            "C": "generic differentiation",
            "D": "integrated cost leadership/differentiation"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q91",
          "sourceNumber": 91,
          "type": "multiple-choice",
          "prompt": "The new generation of lunch trucks serving high-end fare in cities such as New York, San Francisco, and Los Angeles share which of the following a business strategies?",
          "options": {
            "A": "Cost leadership",
            "B": "Focused differentiation",
            "C": "Integrated cost leadership/differentiation",
            "D": "Differentiation"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q92",
          "sourceNumber": 92,
          "type": "multiple-choice",
          "prompt": "The Monteleone Company pays large fees to a highly recognizable, prestigious individual to be the spokesperson for the company's products, luxury private jets. Monteleone is probably following the:",
          "options": {
            "A": "focused cost leadership strategy.",
            "B": "focused differentiation strategy.",
            "C": "integrated cost leadership/differentiation strategy.",
            "D": "total quality strategy."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q93",
          "sourceNumber": 93,
          "type": "multiple-choice",
          "prompt": "The risks of a focus strategy include:",
          "options": {
            "A": "a competitor's ability to use its core competencies to outfocus the focuser by serving an even more narrowly defined segment.",
            "B": "a competitor's ability to use its core competencies to outfocus the focuser by serving an even more broadly defined segment.",
            "C": "decisions by industry-wide competitors to use their resources to serve a wider range of customers' needs than the focuser has been serving.",
            "D": "decisions by focused competitors to use their resources to serve a wider range of customers' needs."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q94",
          "sourceNumber": 94,
          "type": "multiple-choice",
          "prompt": "Focus strategies are:",
          "options": {
            "A": "sheltered from the risks associated with industry-wide strategies because of their niche focus.",
            "B": "able to avoid global risk by focusing on niches in national or regional markets.",
            "C": "faced with additional types of risks than are industry-wide strategies.",
            "D": "more subject to failure than industry-wide strategies."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q95",
          "sourceNumber": 95,
          "type": "multiple-choice",
          "prompt": "New Balance Athletic Shoes target Baby Boomers' needs for well-fitting shoes. The company is unique in that it offers a very broad range of shoe widths. A realistic potential risk New Balance runs in this focused differentiation strategy includes the possibility that:",
          "options": {
            "A": "Baby Boomers may find that they do not need well-fitting shoes, because they will become increasingly sedentary as they age.",
            "B": "a competitor may be able to better use flexible manufacturing systems to make shoes with an individualized fit.",
            "C": "athletic shoes may go out of style.",
            "D": "New Balance shoes may begin to appeal to a wider market, thus losing New Balance's focus advantage."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q96",
          "sourceNumber": 96,
          "type": "multiple-choice",
          "prompt": "Suppose another firm found a way to offer IKEA's customers (young buyers interested in stylish furniture at low cost) additional sources of differentiation while charging the same price or to provide the same service with the same sources of differentiation at a lower price. What category of competitive risk to a focus strategy would this be?",
          "options": {
            "A": "An industry-wide competitor decides that the market segment served by IKEA is worth entering.",
            "B": "Focusing on a more narrowly defined segment and \"outfocusing\" the focuser.",
            "C": "The needs of the customers in this narrow segment have become more similar to those of industry-wide competitors.",
            "D": "Experience can narrow customer's perceptions of value of the firm's differentiated features."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q97",
          "sourceNumber": 97,
          "type": "multiple-choice",
          "prompt": "Zara has pioneered \"cheap chic\" in clothing apparel. Zara offers current and desirable fashion goods at relatively low prices. To implement the strategy, Zara uses sophisticated designers and effective means of managing costs. These are all characteristics of which business level strategy?",
          "options": {
            "A": "Cost leadership",
            "B": "Differentiation",
            "C": "Integrated cost leadership/differentiation",
            "D": "Stuck in the middle"
          },
          "answer": "C"
        },
        {
          "id": "ch4-q98",
          "sourceNumber": 98,
          "type": "multiple-choice",
          "prompt": "Firms use the integrated cost leadership/differentiation strategy because:",
          "options": {
            "A": "other firms have established unassailable market dominance with the other four strategies.",
            "B": "global markets allow for much broader competitive scope.",
            "C": "most consumers want to pay a low price for products with somewhat highly differentiated features.",
            "D": "one strategy is not enough for most large firms."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q99",
          "sourceNumber": 99,
          "type": "multiple-choice",
          "prompt": "The integration of a cost leadership and a differentiation strategy:",
          "options": {
            "A": "is challenging because it increases the number of value-chain activities and support functions in which the firm must become competent.",
            "B": "forces a firm to adapt more slowly to changes in its environment.",
            "C": "allows the firm to avoid being \"stuck in the middle.\"",
            "D": "requires such a large customer base that it is most practical for firms in the global marketplace."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q100",
          "sourceNumber": 100,
          "type": "multiple-choice",
          "prompt": "Target's brand promise \"Expect More. Pay Less\" and appeal to higher-income, fashion-conscious discount shoppers illustrates the _____ strategy.",
          "options": {
            "A": "cost leadership",
            "B": "differentiation",
            "C": "focused differentiation",
            "D": "integrated cost leadership/differentiation"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q101",
          "sourceNumber": 101,
          "type": "multiple-choice",
          "prompt": "J.C. Penney attempted the strategy ______ . But it couldn't out ______ Walmart, nor could it ______ Macy's and Target.",
          "options": {
            "A": "of integrated cost leadership; price; compete with",
            "B": "of focused differentiation; cost; differentiate between",
            "C": "of cost leadership; cost; differentiate between",
            "D": "of focused cost leadership; price; differentiate between"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q102",
          "sourceNumber": 102,
          "type": "multiple-choice",
          "prompt": "Three sources of flexibility in completing primary and support activities are particularly useful for firms using the integrated strategy. These are:",
          "options": {
            "A": "flexible manufacturing systems, reengineering, and Total Quality Management.",
            "B": "outsourcing, reengineering, and flexible manufacturing systems.",
            "C": "outsourcing, Total Quality Management, and information networks.",
            "D": "flexible manufacturing systems, Total Quality Management, and information networks."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q103",
          "sourceNumber": 103,
          "type": "multiple-choice",
          "prompt": "The benefit of a flexible manufacturing system is that:",
          "options": {
            "A": "the lot size needed to manufacture a firm's product efficiently is reduced.",
            "B": "the necessary skill levels of workers are reduced, allowing the firm to reduce costs.",
            "C": "it lends itself to empowerment of employees.",
            "D": "it captures the cost savings of economies of scale."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q104",
          "sourceNumber": 104,
          "type": "multiple-choice",
          "prompt": "A flexible manufacturing system is:",
          "options": {
            "A": "based on the use of temporary and part-time employees as well as outsourcing.",
            "B": "a computer-controlled process that is used to produce a variety of products in moderate, flexible quantities with minimal human intervention.",
            "C": "based on a 360-degree view of the company's relationships with customers.",
            "D": "a system that identifies \"the one best way\" to produce each product in the company's line."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q105",
          "sourceNumber": 105,
          "type": "multiple-choice",
          "prompt": "A nationwide chain of pet stores wishes to identify the tradeoffs that its customers are willing to make between low- cost products such as generic pet foods and differentiated features such as pick-up and delivery of pets for grooming. The best technique for this firm to learn this information would be to use:",
          "options": {
            "A": "information networks.",
            "B": "a flexible manufacturing system.",
            "C": "differentiation development planning.",
            "D": "Enterprise Resource Planning."
          },
          "answer": "A"
        },
        {
          "id": "ch4-q106",
          "sourceNumber": 106,
          "type": "multiple-choice",
          "prompt": "By linking companies with their suppliers, distributors, and customers, ____ provide a company with flexibility.",
          "options": {
            "A": "flexible manufacturing systems",
            "B": "information networks",
            "C": "Total Quality Management systems",
            "D": "capabilities"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q107",
          "sourceNumber": 107,
          "type": "multiple-choice",
          "prompt": "TQM is most helpful to firms following the ____ business strategy.",
          "options": {
            "A": "cost leadership",
            "B": "integrated cost leadership/differentiation",
            "C": "focused cost leadership",
            "D": "focused differentiation"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q108",
          "sourceNumber": 108,
          "type": "multiple-choice",
          "prompt": "The term \"stuck in the middle\":",
          "options": {
            "A": "means adhering to a middle of the road strategy in the face of negative outcomes.",
            "B": "indicates that the customers of the firm are willing to pay only a mid-range price for the product.",
            "C": "reflects the fact that the customers of the firm have only moderate expectations regarding product quality.",
            "D": "means that the firm's cost structure is not low enough to allow it to attractively price its products and that its products are not sufficiently differentiated to create value for its target customer."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q109",
          "sourceNumber": 109,
          "type": "multiple-choice",
          "prompt": "All of the following describe strategies EXCEPT:",
          "options": {
            "A": "they are purposeful.",
            "B": "they cannibalize the old strategy.",
            "C": "they precede the taking of actions to which they apply.",
            "D": "they demonstrate a shared understanding of the firm's vision and mission."
          },
          "answer": "B"
        },
        {
          "id": "ch4-q110",
          "sourceNumber": 110,
          "type": "multiple-choice",
          "prompt": "More choices and easily accessible information about the functionality of firms' products are creating increasingly ______ customers.",
          "options": {
            "A": "sophisticated and knowledgeable",
            "B": "loyal",
            "C": "dissatisfied",
            "D": "content"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q111",
          "sourceNumber": 111,
          "type": "multiple-choice",
          "prompt": "The ______ dimension of relationships with customers is concerned with the firm's access and connection to customers.",
          "options": {
            "A": "loyalty",
            "B": "reach",
            "C": "richness",
            "D": "affiliation"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q112",
          "sourceNumber": 112,
          "type": "multiple-choice",
          "prompt": "Reach is an especially critical dimension for which firm?",
          "options": {
            "A": "Google",
            "B": "J.C. Penney",
            "C": "Blockbuster",
            "D": "Colgate-Palmolive"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q113",
          "sourceNumber": 113,
          "type": "multiple-choice",
          "prompt": "Customer ratings of products they bought online is an example of:",
          "options": {
            "A": "loyalty.",
            "B": "reach.",
            "C": "richness.",
            "D": "affiliation."
          },
          "answer": "C"
        },
        {
          "id": "ch4-q114",
          "sourceNumber": 114,
          "type": "multiple-choice",
          "prompt": "A company selling diapers knows the market is for people with young children. However, within that segment they can further divide the market by a demographic factor like:",
          "options": {
            "A": "culture.",
            "B": "lifestyle.",
            "C": "consumption pattern.",
            "D": "income."
          },
          "answer": "D"
        },
        {
          "id": "ch4-q115",
          "sourceNumber": 115,
          "type": "multiple-choice",
          "prompt": "When firms use core competencies to implement value-creating strategies they are answering the \"______\" question.",
          "options": {
            "A": "who",
            "B": "what",
            "C": "why",
            "D": "how"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q116",
          "sourceNumber": 116,
          "type": "multiple-choice",
          "prompt": "Stage in the family life cycle is a ______ factor.",
          "options": {
            "A": "demographic",
            "B": "socioeconomic",
            "C": "psychological",
            "D": "perceptual"
          },
          "answer": "B"
        },
        {
          "id": "ch4-q117",
          "sourceNumber": 117,
          "type": "multiple-choice",
          "prompt": "The book The Dyslexic Advantage appeals to a market of educators, people with dyslexia, their friends, family, and coworkers. This is customer segmentation by ______ factors.",
          "options": {
            "A": "demographic",
            "B": "socioeconomic",
            "C": "psychological",
            "D": "consumption"
          },
          "answer": "C"
        },
        {
          "id": "ch4-q118",
          "sourceNumber": 118,
          "type": "multiple-choice",
          "prompt": "Religious beliefs are an example of customer segmentation by ______ factors.",
          "options": {
            "A": "demographic",
            "B": "socioeconomic",
            "C": "geographic",
            "D": "psychological"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q119",
          "sourceNumber": 119,
          "type": "multiple-choice",
          "prompt": "Historically, women have paid more for dry cleaning than men. Signature Cleaners advertises \"equal price\" for all customers. Signature Cleaners appeals to women, which is market segmentation by ______ factors.",
          "options": {
            "A": "demographic",
            "B": "socioeconomic",
            "C": "geographic",
            "D": "consumption pattern"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q120",
          "sourceNumber": 120,
          "type": "multiple-choice",
          "prompt": "Chelsea Milling Company makes Jiffy packaged baking mixes. It was established in 1930. It has never spent one cent on advertising, which is one reason it is able to pursue a(n) ______ strategy.",
          "options": {
            "A": "differentiation",
            "B": "focused differentiation",
            "C": "integrated cost leadership/differentiation",
            "D": "cost leadership"
          },
          "answer": "D"
        },
        {
          "id": "ch4-q121",
          "sourceNumber": 121,
          "type": "multiple-choice",
          "prompt": "Mercedes mass produces luxury vehicles at a premium price. It uses a(n) ______ strategy.",
          "options": {
            "A": "differentiation",
            "B": "focused differentiation",
            "C": "integrated cost leadership/differentiation",
            "D": "focused cost leadership"
          },
          "answer": "A"
        },
        {
          "id": "ch4-q122",
          "sourceNumber": 122,
          "type": "multiple-choice",
          "prompt": "A firm using a(n) ______ strategy generally needs to operate \"below the radar\" of larger and more resource rich firms that serve the broader market.",
          "options": {
            "A": "cost leadership",
            "B": "differentiation",
            "C": "focused",
            "D": "integrated cost leadership/differentiation"
          },
          "answer": "C"
        }
      ]
    }
  ]
};
