const STORAGE_KEY = "mis-midterm-review-v1";

const dom = {
  homeView: document.querySelector("#home-view"),
  quizView: document.querySelector("#quiz-view"),
  resultView: document.querySelector("#result-view"),
  chapterGrid: document.querySelector("#chapter-grid"),
  continueButton: document.querySelector("#continue-button"),
  randomButton: document.querySelector("#random-button"),
  allWrongButton: document.querySelector("#all-wrong-button"),
  allWrongCount: document.querySelector("#all-wrong-count"),
  resetAllButton: document.querySelector("#reset-all-button"),
  overallRing: document.querySelector("#overall-ring"),
  overallPercent: document.querySelector("#overall-percent"),
  overallAnswered: document.querySelector("#overall-answered"),
  overallTotal: document.querySelector("#overall-total"),
  overallDetail: document.querySelector("#overall-detail"),
  headerChapterCount: document.querySelector("#header-chapter-count"),
  headerQuestionCount: document.querySelector("#header-question-count"),
  backButton: document.querySelector("#back-button"),
  mobileBackButton: document.querySelector("#mobile-back-button"),
  sidebarKicker: document.querySelector("#sidebar-kicker"),
  sidebarTitle: document.querySelector("#sidebar-title"),
  correctCount: document.querySelector("#correct-count"),
  answeredCount: document.querySelector("#answered-count"),
  accuracyCount: document.querySelector("#accuracy-count"),
  sidebarProgressText: document.querySelector("#sidebar-progress-text"),
  sidebarProgressBar: document.querySelector("#sidebar-progress-bar"),
  shuffleButton: document.querySelector("#shuffle-button"),
  resetChapterButton: document.querySelector("#reset-chapter-button"),
  mobileChapter: document.querySelector("#mobile-chapter"),
  mobileProgress: document.querySelector("#mobile-progress"),
  questionPosition: document.querySelector("#question-position"),
  questionStatus: document.querySelector("#question-status"),
  questionText: document.querySelector("#question-text"),
  optionsList: document.querySelector("#options-list"),
  feedback: document.querySelector("#feedback"),
  previousButton: document.querySelector("#previous-button"),
  checkButton: document.querySelector("#check-button"),
  nextButton: document.querySelector("#next-button"),
  resultBackButton: document.querySelector("#result-back-button"),
  resultKicker: document.querySelector("#result-kicker"),
  resultTitle: document.querySelector("#result-title"),
  resultPercent: document.querySelector("#result-percent"),
  resultFraction: document.querySelector("#result-fraction"),
  resultMessage: document.querySelector("#result-message"),
  reviewWrongButton: document.querySelector("#review-wrong-button"),
  retryButton: document.querySelector("#retry-button"),
  mistakeList: document.querySelector("#mistake-list"),
  modal: document.querySelector("#confirm-modal"),
  modalTitle: document.querySelector("#modal-title"),
  modalCopy: document.querySelector("#modal-copy"),
  modalConfirmButton: document.querySelector("#modal-confirm-button"),
};

let bank = null;
let saved = loadSaved();
let currentChapter = null;
let currentMode = "normal";
let sessionIds = [];
let sessionResponses = {};
let cursor = 0;
let draftSelection = null;
let modalAction = null;

function loadSaved() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { chapters: {}, lastChapter: null };
  } catch {
    return { chapters: {}, lastChapter: null };
  }
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
}

function chapterState(number) {
  const key = String(number);
  if (!saved.chapters[key]) saved.chapters[key] = { answers: {}, order: [] };
  return saved.chapters[key];
}

function questionById(id) {
  if (currentChapter) {
    const question = currentChapter.questions.find((item) => item.id === id);
    if (question) return question;
  }
  for (const chapter of bank.chapters) {
    const question = chapter.questions.find((item) => item.id === id);
    if (question) return question;
  }
  return null;
}

function chapterForQuestion(id) {
  return bank.chapters.find((chapter) => chapter.questions.some((question) => question.id === id));
}

function isReviewMode() {
  return currentMode === "wrong" || currentMode === "all-wrong";
}

function splitTitle(chapter) {
  return chapter.title.replace(/^Chapter\s+\d+\s*/i, "").trim();
}

function showView(name) {
  dom.homeView.hidden = name !== "home";
  dom.quizView.hidden = name !== "quiz";
  dom.resultView.hidden = name !== "result";
  document.querySelector(".site-header").hidden = name === "quiz";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function getStats(chapter) {
  const answers = chapterState(chapter.number).answers;
  const answered = chapter.questions.filter((question) => answers[question.id]).length;
  const correct = chapter.questions.filter((question) => answers[question.id]?.correct).length;
  return { answered, correct, total: chapter.questions.length };
}

function getWrongCount(chapter) {
  const answers = chapterState(chapter.number).answers;
  return chapter.questions.filter((question) => answers[question.id] && !answers[question.id].correct).length;
}

function shuffled(values) {
  const copy = [...values];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
  }
  if (copy.length > 1 && copy.every((value, index) => value === values[index])) {
    copy.push(copy.shift());
  }
  return copy;
}

function renderHome() {
  const total = bank.chapters.reduce((sum, chapter) => sum + chapter.questions.length, 0);
  const stats = bank.chapters.map(getStats);
  const answered = stats.reduce((sum, item) => sum + item.answered, 0);
  const correct = stats.reduce((sum, item) => sum + item.correct, 0);
  const wrong = bank.chapters.reduce((sum, chapter) => sum + getWrongCount(chapter), 0);
  const percent = total ? Math.round((answered / total) * 100) : 0;

  dom.headerChapterCount.textContent = bank.chapters.length;
  dom.headerQuestionCount.textContent = total;
  dom.overallTotal.textContent = total;
  dom.overallAnswered.textContent = answered;
  dom.overallPercent.textContent = `${percent}%`;
  dom.overallRing.style.setProperty("--percent", percent);
  dom.overallDetail.textContent = answered
    ? `目前答對 ${correct} 題，整體正確率 ${Math.round((correct / answered) * 100)}%；另有 ${wrong} 題待複習。`
    : "挑一章開始，把進度累積起來。";
  dom.allWrongButton.disabled = wrong === 0;
  dom.allWrongCount.textContent = wrong ? `${wrong} 題 · 混合隨機` : "目前沒有錯題";

  const lastChapter = bank.chapters.find((chapter) => chapter.number === saved.lastChapter);
  dom.continueButton.querySelector("span").textContent = lastChapter
    ? `繼續第 ${lastChapter.number} 章`
    : "從第 1 章開始";

  dom.chapterGrid.innerHTML = bank.chapters.map((chapter) => {
    const stat = getStats(chapter);
    const wrongCount = getWrongCount(chapter);
    const progress = Math.round((stat.answered / stat.total) * 100);
    const label = stat.answered === stat.total ? "已完成" : `${stat.answered} / ${stat.total}`;
    return `
      <article class="chapter-card">
        <button class="chapter-card-main" type="button" data-chapter="${chapter.number}">
          <span class="chapter-card-top">
            <span class="chapter-number">Chapter ${String(chapter.number).padStart(2, "0")}</span>
            <span class="chapter-count">${chapter.questions.length} 題</span>
          </span>
          <h3>${escapeHtml(splitTitle(chapter))}</h3>
          <span class="chapter-card-footer">
            <span class="chapter-card-progress"><span>${label}</span><span>${progress}%</span></span>
            <span class="progress-track"><span style="width:${progress}%"></span></span>
          </span>
        </button>
        <button class="wrong-review-button" type="button" data-wrong-chapter="${chapter.number}" ${wrongCount ? "" : "disabled"}>
          <span>錯題複習</span><span>${wrongCount ? `${wrongCount} 題 · 自動打亂` : "目前沒有錯題"}</span>
        </button>
      </article>`;
  }).join("");

  dom.chapterGrid.querySelectorAll("[data-chapter]").forEach((button) => {
    button.addEventListener("click", () => startChapter(Number(button.dataset.chapter)));
  });
  dom.chapterGrid.querySelectorAll("[data-wrong-chapter]").forEach((button) => {
    button.addEventListener("click", () => startChapter(Number(button.dataset.wrongChapter), "wrong"));
  });
}

function startAllWrong() {
  currentChapter = null;
  currentMode = "all-wrong";
  sessionResponses = {};
  sessionIds = shuffled(bank.chapters.flatMap((chapter) => {
    const answers = chapterState(chapter.number).answers;
    return chapter.questions
      .filter((question) => answers[question.id] && !answers[question.id].correct)
      .map((question) => question.id);
  }));

  if (!sessionIds.length) {
    renderHome();
    showView("home");
    return;
  }

  cursor = 0;
  draftSelection = null;
  dom.sidebarKicker.textContent = "Integrated review";
  dom.sidebarTitle.textContent = "跨章節錯題複習";
  dom.mobileChapter.textContent = "跨章節錯題複習";
  dom.resetChapterButton.hidden = true;
  dom.shuffleButton.textContent = "重新打亂全部錯題";
  showView("quiz");
  renderQuestion();
}

function startChapter(number, mode = "normal") {
  currentChapter = bank.chapters.find((chapter) => chapter.number === number);
  if (!currentChapter) return;

  const state = chapterState(number);
  currentMode = mode;
  sessionResponses = {};
  if (mode === "wrong") {
    sessionIds = shuffled(currentChapter.questions
      .filter((question) => state.answers[question.id] && !state.answers[question.id].correct)
      .map((question) => question.id));
    if (!sessionIds.length) {
      renderHome();
      showView("home");
      return;
    }
  } else {
    sessionIds = state.order.length === currentChapter.questions.length
      ? [...state.order]
      : currentChapter.questions.map((question) => question.id);
  }
  if (!sessionIds.length) sessionIds = currentChapter.questions.map((question) => question.id);

  const firstUnanswered = mode === "wrong" ? 0 : sessionIds.findIndex((id) => !state.answers[id]);
  cursor = firstUnanswered >= 0 ? firstUnanswered : 0;
  draftSelection = null;
  saved.lastChapter = number;
  persist();

  dom.resetChapterButton.hidden = false;
  dom.shuffleButton.textContent = mode === "wrong" ? "重新打亂錯題" : "打亂題目順序";
  dom.sidebarKicker.textContent = mode === "wrong" ? `錯題複習 · Chapter ${String(number).padStart(2, "0")}` : `Chapter ${String(number).padStart(2, "0")}`;
  dom.mobileChapter.textContent = mode === "wrong" ? `錯題複習 · Chapter ${number}` : `Chapter ${number}`;
  dom.sidebarTitle.textContent = splitTitle(currentChapter);
  showView("quiz");
  renderQuestion();
}

function renderQuestion() {
  const question = questionById(sessionIds[cursor]);
  const questionChapter = chapterForQuestion(question.id);
  const state = chapterState(questionChapter.number);
  const recorded = isReviewMode() ? sessionResponses[question.id] : state.answers[question.id];
  const stats = isReviewMode()
    ? {
        answered: Object.keys(sessionResponses).length,
        correct: Object.values(sessionResponses).filter((response) => response.correct).length,
        total: sessionIds.length,
      }
    : getStats(currentChapter);
  draftSelection = recorded?.selected || null;

  const chapterLabel = `Chapter ${questionChapter.number}`;
  dom.questionPosition.textContent = `${isReviewMode() ? "錯題" : "Question"} ${cursor + 1} of ${sessionIds.length}${currentMode === "all-wrong" ? ` · ${chapterLabel}` : ""}`;
  dom.mobileProgress.textContent = `${cursor + 1} / ${sessionIds.length}`;
  if (currentMode === "all-wrong") {
    dom.sidebarTitle.textContent = `${chapterLabel} · ${splitTitle(questionChapter)}`;
    dom.mobileChapter.textContent = `整合錯題 · ${chapterLabel}`;
  }
  dom.questionText.textContent = question.prompt;
  dom.previousButton.disabled = cursor === 0;
  dom.nextButton.textContent = cursor === sessionIds.length - 1 ? "完成本輪 →" : "下一題 →";

  dom.optionsList.innerHTML = Object.entries(question.options).map(([letter, text], index) => {
    const isSelected = draftSelection === letter;
    const classes = ["option"];
    if (isSelected) classes.push("selected");
    if (recorded && letter === question.answer) classes.push("correct");
    if (recorded && isSelected && letter !== question.answer) classes.push("incorrect");
    return `
      <button class="${classes.join(" ")}" type="button" role="radio"
        aria-checked="${isSelected}" data-option="${letter}" ${recorded ? "disabled" : ""}>
        <span class="option-letter">${letter}</span>
        <span class="option-text">${escapeHtml(text)}</span>
      </button>`;
  }).join("");

  dom.optionsList.querySelectorAll("[data-option]").forEach((button) => {
    button.addEventListener("click", () => selectOption(button.dataset.option));
  });

  if (recorded) {
    const correct = recorded.correct;
    dom.questionStatus.textContent = correct ? "答對" : "答錯";
    dom.questionStatus.className = `status-pill ${correct ? "correct" : "incorrect"}`;
    dom.feedback.hidden = false;
    dom.feedback.className = `feedback ${correct ? "correct" : "incorrect"}`;
    dom.feedback.textContent = correct
      ? `答對了。正確答案是 ${question.answer}。`
      : `這題的正確答案是 ${question.answer}：${question.options[question.answer]}`;
    dom.checkButton.hidden = true;
    dom.nextButton.hidden = false;
  } else {
    dom.questionStatus.textContent = "尚未作答";
    dom.questionStatus.className = "status-pill";
    dom.feedback.hidden = true;
    dom.checkButton.hidden = false;
    dom.checkButton.disabled = !draftSelection;
    dom.nextButton.hidden = true;
  }

  dom.correctCount.textContent = stats.correct;
  dom.answeredCount.textContent = stats.answered;
  dom.accuracyCount.textContent = stats.answered ? `${Math.round((stats.correct / stats.answered) * 100)}%` : "—";
  dom.sidebarProgressText.textContent = `${stats.answered} / ${stats.total}`;
  dom.sidebarProgressBar.style.width = `${Math.round((stats.answered / stats.total) * 100)}%`;
}

function selectOption(letter) {
  draftSelection = letter;
  dom.optionsList.querySelectorAll("[data-option]").forEach((button) => {
    const selected = button.dataset.option === letter;
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-checked", selected);
  });
  dom.checkButton.disabled = false;
}

function checkAnswer() {
  if (!draftSelection) return;
  const question = questionById(sessionIds[cursor]);
  const questionChapter = chapterForQuestion(question.id);
  const state = chapterState(questionChapter.number);
  const response = {
    selected: draftSelection,
    correct: draftSelection === question.answer,
    answeredAt: Date.now(),
  };
  state.answers[question.id] = response;
  if (isReviewMode()) sessionResponses[question.id] = response;
  persist();
  renderQuestion();
}

function nextQuestion() {
  if (cursor < sessionIds.length - 1) {
    cursor += 1;
    draftSelection = null;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else {
    renderResult();
  }
}

function previousQuestion() {
  if (cursor === 0) return;
  cursor -= 1;
  draftSelection = null;
  renderQuestion();
}

function renderResult() {
  const questions = sessionIds.map(questionById);
  const state = currentChapter ? chapterState(currentChapter.number) : null;
  const responses = isReviewMode() ? sessionResponses : state.answers;
  const correct = questions.filter((question) => responses[question.id]?.correct).length;
  const answered = questions.filter((question) => responses[question.id]).length;
  const wrong = questions.filter((question) => responses[question.id] && !responses[question.id].correct);
  const percent = answered ? Math.round((correct / answered) * 100) : 0;

  dom.resultKicker.textContent = currentMode === "all-wrong" ? "Integrated review complete" : "Chapter complete";
  dom.resultTitle.textContent = currentMode === "all-wrong"
    ? "整合錯題完成"
    : currentMode === "wrong"
      ? "錯題複習完成"
      : "本章完成";
  dom.resultPercent.textContent = `${percent}%`;
  dom.resultFraction.textContent = `${correct} / ${questions.length} 題答對`;
  dom.resultMessage.textContent = percent >= 90
    ? currentMode === "all-wrong" ? "跨章節錯題掌握得很穩，繼續保持。" : "掌握得很穩，這章可以先放心了。"
    : percent >= 70
      ? "基礎已經很不錯，再把錯題練熟就更完整。"
      : "先從錯題開始補強；每輪都會比上一輪更熟。";
  dom.reviewWrongButton.hidden = wrong.length === 0;
  dom.reviewWrongButton.textContent = currentMode === "all-wrong"
    ? "再練全部錯題（混合隨機）"
    : currentMode === "wrong"
      ? "再練本輪錯題（隨機）"
      : "錯題複習（隨機）";
  dom.retryButton.textContent = currentMode === "all-wrong"
    ? "返回章節總覽"
    : currentMode === "wrong"
      ? "返回章節練習"
      : "整章再練一次";

  dom.mistakeList.innerHTML = wrong.length
    ? `<h2 class="mistake-heading">本輪錯題 ${wrong.length} 題</h2>` + wrong.map((question) => `
        <div class="mistake-item">
          <span>CHAPTER ${chapterForQuestion(question.id).number} · QUESTION ${question.sourceNumber} · ANSWER ${question.answer}</span>
          <p>${escapeHtml(question.prompt)}</p>
        </div>`).join("")
    : `<div class="mistake-item" style="border-color:var(--green-mid);background:var(--mint)">
        <span style="color:var(--green-mid)">PERFECT</span><p>這一輪沒有錯題。</p>
      </div>`;
  showView("result");
}

function shuffleCurrentChapter() {
  if (isReviewMode()) {
    sessionIds = shuffled(sessionIds);
    const firstUnanswered = sessionIds.findIndex((id) => !sessionResponses[id]);
    cursor = firstUnanswered >= 0 ? firstUnanswered : 0;
    renderQuestion();
    return;
  }
  const state = chapterState(currentChapter.number);
  const ids = shuffled(currentChapter.questions.map((question) => question.id));
  state.order = ids;
  persist();
  sessionIds = [...ids];
  cursor = 0;
  renderQuestion();
}

function openModal({ title, copy, action }) {
  dom.modalTitle.textContent = title;
  dom.modalCopy.textContent = copy;
  modalAction = action;
  dom.modal.hidden = false;
  dom.modalConfirmButton.focus();
}

function closeModal() {
  dom.modal.hidden = true;
  modalAction = null;
}

function resetChapter(number) {
  delete saved.chapters[String(number)];
  persist();
  startChapter(number);
}

function escapeHtml(value) {
  return value.replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character]);
}

function bindEvents() {
  document.querySelector(".brand").addEventListener("click", (event) => {
    event.preventDefault();
    renderHome();
    showView("home");
  });
  dom.continueButton.addEventListener("click", () => startChapter(saved.lastChapter || bank.chapters[0].number));
  dom.randomButton.addEventListener("click", () => {
    const chapter = bank.chapters[Math.floor(Math.random() * bank.chapters.length)];
    startChapter(chapter.number);
  });
  dom.allWrongButton.addEventListener("click", startAllWrong);
  [dom.backButton, dom.mobileBackButton, dom.resultBackButton].forEach((button) => {
    button.addEventListener("click", () => { renderHome(); showView("home"); });
  });
  dom.checkButton.addEventListener("click", checkAnswer);
  dom.nextButton.addEventListener("click", nextQuestion);
  dom.previousButton.addEventListener("click", previousQuestion);
  dom.shuffleButton.addEventListener("click", shuffleCurrentChapter);
  dom.resetChapterButton.addEventListener("click", () => {
    if (!currentChapter) return;
    openModal({
      title: `重設第 ${currentChapter.number} 章進度？`,
      copy: "本章的作答紀錄與錯題標記都會被清除。",
      action: () => resetChapter(currentChapter.number),
    });
  });
  dom.resetAllButton.addEventListener("click", () => openModal({
    title: "清除全部複習進度？",
    copy: "六個章節的作答紀錄都會被清除，這個動作無法復原。",
    action: () => {
      saved = { chapters: {}, lastChapter: null };
      persist();
      renderHome();
    },
  }));
  document.querySelectorAll("[data-close-modal]").forEach((element) => element.addEventListener("click", closeModal));
  dom.modalConfirmButton.addEventListener("click", () => {
    const action = modalAction;
    closeModal();
    action?.();
  });
  dom.reviewWrongButton.addEventListener("click", () => {
    if (currentMode === "all-wrong") startAllWrong();
    else startChapter(currentChapter.number, "wrong");
  });
  dom.retryButton.addEventListener("click", () => {
    if (currentMode === "all-wrong") {
      renderHome();
      showView("home");
      return;
    }
    if (currentMode === "wrong") {
      startChapter(currentChapter.number);
      return;
    }
    delete saved.chapters[String(currentChapter.number)];
    persist();
    startChapter(currentChapter.number);
  });
  document.addEventListener("keydown", (event) => {
    if (!dom.modal.hidden && event.key === "Escape") return closeModal();
    if (dom.quizView.hidden) return;
    if (["1", "2", "3", "4", "5"].includes(event.key) && !dom.checkButton.hidden) {
      const letter = ["A", "B", "C", "D", "E"][Number(event.key) - 1];
      selectOption(letter);
    }
    if (event.key === "Enter") {
      if (!dom.nextButton.hidden) nextQuestion();
      else if (!dom.checkButton.disabled) checkAnswer();
    }
  });
}

function init() {
  try {
    bank = window.QUESTION_BANK;
    if (!bank?.chapters?.length) throw new Error("Question bank could not be loaded.");
    bindEvents();
    renderHome();
  } catch (error) {
    document.querySelector("main").innerHTML = `<section class="view"><div class="result-card"><h1>載入失敗</h1><p>${escapeHtml(error.message)}</p></div></section>`;
  }
}

init();
